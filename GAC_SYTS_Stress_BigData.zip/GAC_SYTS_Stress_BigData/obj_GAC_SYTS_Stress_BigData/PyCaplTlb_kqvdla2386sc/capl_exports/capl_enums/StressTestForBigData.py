from enum import IntEnum

class extPSChannel(IntEnum):
    CH1 = 8
    CH2 = 2
    CH3 = 3
    CH4 = 4

class PSCHOutputSt(IntEnum):
    CHSt_ON = 1
    CHSt_OFF = 0


