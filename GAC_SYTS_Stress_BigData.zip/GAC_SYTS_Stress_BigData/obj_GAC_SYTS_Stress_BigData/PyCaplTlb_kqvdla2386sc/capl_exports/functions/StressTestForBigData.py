from vector.canoe import uint8, uint16, uint32, uint64, int8, int16, int32, int64, double
import RTPython39
from typing import overload
from enum import IntEnum
from ..capl_enums.StressTestForBigData import *

def Fn_RS232_ConnectExtPS(ExternalPowerCOMPortNum: int16, BandRate: uint32) -> None:
    if ExternalPowerCOMPortNum < -32_768 or ExternalPowerCOMPortNum > 32_767:
        raise ValueError("ExternalPowerCOMPortNum must be in the in the inclusive range (-32_768, 32_767).")
    if BandRate < 0 or BandRate > 4_294_967_295:
        raise ValueError("BandRate must be in the in the inclusive range (0, 4_294_967_295).")
    RTPython39.test_support_create_capl_if_function("Fn_RS232_ConnectExtPS", 0)
    RTPython39.test_support_add_if_parameter_int(ExternalPowerCOMPortNum)
    RTPython39.test_support_add_if_parameter_dword(BandRate)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_RS232_DisconnectExtPS() -> None:
    RTPython39.test_support_create_capl_if_function("Fn_RS232_DisconnectExtPS", 0)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_Set_PSVoltage(CH_num: extPSChannel, VoltageValue: float) -> None:
    if CH_num < -2_147_483_648 or CH_num > 2_147_483_647:
        raise ValueError("CH_num must be in the in the inclusive range (-2_147_483_648, 2_147_483_647).")
    RTPython39.test_support_create_capl_if_function("Fn_Set_PSVoltage", 0)
    RTPython39.test_support_add_if_parameter_int64(CH_num)
    RTPython39.test_support_add_if_parameter_double(VoltageValue)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_Set_PSCurrent(CH_num: extPSChannel, currentValue: float) -> None:
    if CH_num < -2_147_483_648 or CH_num > 2_147_483_647:
        raise ValueError("CH_num must be in the in the inclusive range (-2_147_483_648, 2_147_483_647).")
    RTPython39.test_support_create_capl_if_function("Fn_Set_PSCurrent", 0)
    RTPython39.test_support_add_if_parameter_int64(CH_num)
    RTPython39.test_support_add_if_parameter_double(currentValue)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_Set_PSVoltageAndCurrent(CH_num: extPSChannel, VoltageValue: float, currentValue: float) -> None:
    if CH_num < -2_147_483_648 or CH_num > 2_147_483_647:
        raise ValueError("CH_num must be in the in the inclusive range (-2_147_483_648, 2_147_483_647).")
    RTPython39.test_support_create_capl_if_function("Fn_Set_PSVoltageAndCurrent", 0)
    RTPython39.test_support_add_if_parameter_int64(CH_num)
    RTPython39.test_support_add_if_parameter_double(VoltageValue)
    RTPython39.test_support_add_if_parameter_double(currentValue)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_Set_PSChannelOutput(CH_num: extPSChannel, OutputState: PSCHOutputSt) -> None:
    if CH_num < -2_147_483_648 or CH_num > 2_147_483_647:
        raise ValueError("CH_num must be in the in the inclusive range (-2_147_483_648, 2_147_483_647).")
    if OutputState < -2_147_483_648 or OutputState > 2_147_483_647:
        raise ValueError("OutputState must be in the in the inclusive range (-2_147_483_648, 2_147_483_647).")
    RTPython39.test_support_create_capl_if_function("Fn_Set_PSChannelOutput", 0)
    RTPython39.test_support_add_if_parameter_int64(CH_num)
    RTPython39.test_support_add_if_parameter_int64(OutputState)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_GetExtPowerSupplyCurrent(CH_num: extPSChannel) -> float:
    if CH_num < -2_147_483_648 or CH_num > 2_147_483_647:
        raise ValueError("CH_num must be in the in the inclusive range (-2_147_483_648, 2_147_483_647).")
    RTPython39.test_support_create_capl_if_function("Fn_GetExtPowerSupplyCurrent", 0)
    RTPython39.test_support_add_if_parameter_int64(CH_num)
    return RTPython39.test_support_call_interface_function_double("", "")
def Fn_GetExtPowerSupplyVoltage(CH_num: extPSChannel) -> float:
    if CH_num < -2_147_483_648 or CH_num > 2_147_483_647:
        raise ValueError("CH_num must be in the in the inclusive range (-2_147_483_648, 2_147_483_647).")
    RTPython39.test_support_create_capl_if_function("Fn_GetExtPowerSupplyVoltage", 0)
    RTPython39.test_support_add_if_parameter_int64(CH_num)
    return RTPython39.test_support_call_interface_function_double("", "")
def Fn_Init_ExtPowerSupply() -> None:
    RTPython39.test_support_create_capl_if_function("Fn_Init_ExtPowerSupply", 0)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_Reset_ExtPowerSupply() -> None:
    RTPython39.test_support_create_capl_if_function("Fn_Reset_ExtPowerSupply", 0)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_RS232_ConnectUART(UARTLogCOMPortNum: int16, BandRate: uint32) -> None:
    if UARTLogCOMPortNum < -32_768 or UARTLogCOMPortNum > 32_767:
        raise ValueError("UARTLogCOMPortNum must be in the in the inclusive range (-32_768, 32_767).")
    if BandRate < 0 or BandRate > 4_294_967_295:
        raise ValueError("BandRate must be in the in the inclusive range (0, 4_294_967_295).")
    RTPython39.test_support_create_capl_if_function("Fn_RS232_ConnectUART", 0)
    RTPython39.test_support_add_if_parameter_int(UARTLogCOMPortNum)
    RTPython39.test_support_add_if_parameter_dword(BandRate)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_RS232_DisconnectUART() -> None:
    RTPython39.test_support_create_capl_if_function("Fn_RS232_DisconnectUART", 0)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_clearLogBuffer() -> None:
    RTPython39.test_support_create_capl_if_function("Fn_clearLogBuffer", 0)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_checkStrTest(PortNumber: int16) -> None:
    if PortNumber < -32_768 or PortNumber > 32_767:
        raise ValueError("PortNumber must be in the in the inclusive range (-32_768, 32_767).")
    RTPython39.test_support_create_capl_if_function("Fn_checkStrTest", 0)
    RTPython39.test_support_add_if_parameter_int(PortNumber)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_setLogReceiveDoneFlag(PortNumber: int16, doneFlag: str) -> None:
    if PortNumber < -32_768 or PortNumber > 32_767:
        raise ValueError("PortNumber must be in the in the inclusive range (-32_768, 32_767).")
    RTPython39.test_support_create_capl_if_function("Fn_setLogReceiveDoneFlag", 0)
    RTPython39.test_support_add_if_parameter_int(PortNumber)
    RTPython39.test_support_add_if_parameter_char(doneFlag)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_SendLinuxcommand(UARTLogCOMPortNum: int16, inputCommand: str) -> None:
    if UARTLogCOMPortNum < -32_768 or UARTLogCOMPortNum > 32_767:
        raise ValueError("UARTLogCOMPortNum must be in the in the inclusive range (-32_768, 32_767).")
    RTPython39.test_support_create_capl_if_function("Fn_SendLinuxcommand", 0)
    RTPython39.test_support_add_if_parameter_int(UARTLogCOMPortNum)
    RTPython39.test_support_add_if_parameter_char(inputCommand)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_LinuxLoginRoot(UARTLogCOMPortNum: int16) -> None:
    if UARTLogCOMPortNum < -32_768 or UARTLogCOMPortNum > 32_767:
        raise ValueError("UARTLogCOMPortNum must be in the in the inclusive range (-32_768, 32_767).")
    RTPython39.test_support_create_capl_if_function("Fn_LinuxLoginRoot", 0)
    RTPython39.test_support_add_if_parameter_int(UARTLogCOMPortNum)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_LinuxLoginNormalUser(UARTLogCOMPortNum: int16, username: str, password: str) -> None:
    if UARTLogCOMPortNum < -32_768 or UARTLogCOMPortNum > 32_767:
        raise ValueError("UARTLogCOMPortNum must be in the in the inclusive range (-32_768, 32_767).")
    RTPython39.test_support_create_capl_if_function("Fn_LinuxLoginNormalUser", 0)
    RTPython39.test_support_add_if_parameter_int(UARTLogCOMPortNum)
    RTPython39.test_support_add_if_parameter_char(username)
    RTPython39.test_support_add_if_parameter_char(password)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_WriteLogToLocalFile(PortNumber: int16, LogFilename: str) -> None:
    if PortNumber < -32_768 or PortNumber > 32_767:
        raise ValueError("PortNumber must be in the in the inclusive range (-32_768, 32_767).")
    RTPython39.test_support_create_capl_if_function("Fn_WriteLogToLocalFile", 0)
    RTPython39.test_support_add_if_parameter_int(PortNumber)
    RTPython39.test_support_add_if_parameter_char(LogFilename)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_setTargetStr1(goalTxt1: str) -> None:
    RTPython39.test_support_create_capl_if_function("Fn_setTargetStr1", 0)
    RTPython39.test_support_add_if_parameter_char(goalTxt1)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_setTargetStr2(goalTxt1: str, goalTxt2: str) -> None:
    RTPython39.test_support_create_capl_if_function("Fn_setTargetStr2", 0)
    RTPython39.test_support_add_if_parameter_char(goalTxt1)
    RTPython39.test_support_add_if_parameter_char(goalTxt2)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_setTargetStr3(goalTxt1: str, goalTxt2: str, goalTxt3: str) -> None:
    RTPython39.test_support_create_capl_if_function("Fn_setTargetStr3", 0)
    RTPython39.test_support_add_if_parameter_char(goalTxt1)
    RTPython39.test_support_add_if_parameter_char(goalTxt2)
    RTPython39.test_support_add_if_parameter_char(goalTxt3)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_setTargetStr4(goalTxt1: str, goalTxt2: str, goalTxt3: str, goalTxt4: str) -> None:
    RTPython39.test_support_create_capl_if_function("Fn_setTargetStr4", 0)
    RTPython39.test_support_add_if_parameter_char(goalTxt1)
    RTPython39.test_support_add_if_parameter_char(goalTxt2)
    RTPython39.test_support_add_if_parameter_char(goalTxt3)
    RTPython39.test_support_add_if_parameter_char(goalTxt4)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_setTargetStr5(goalTxt1: str, goalTxt2: str, goalTxt3: str, goalTxt4: str, goalTxt5: str) -> None:
    RTPython39.test_support_create_capl_if_function("Fn_setTargetStr5", 0)
    RTPython39.test_support_add_if_parameter_char(goalTxt1)
    RTPython39.test_support_add_if_parameter_char(goalTxt2)
    RTPython39.test_support_add_if_parameter_char(goalTxt3)
    RTPython39.test_support_add_if_parameter_char(goalTxt4)
    RTPython39.test_support_add_if_parameter_char(goalTxt5)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_setTargetStr6(goalTxt1: str, goalTxt2: str, goalTxt3: str, goalTxt4: str, goalTxt5: str, goalTxt6: str) -> None:
    RTPython39.test_support_create_capl_if_function("Fn_setTargetStr6", 0)
    RTPython39.test_support_add_if_parameter_char(goalTxt1)
    RTPython39.test_support_add_if_parameter_char(goalTxt2)
    RTPython39.test_support_add_if_parameter_char(goalTxt3)
    RTPython39.test_support_add_if_parameter_char(goalTxt4)
    RTPython39.test_support_add_if_parameter_char(goalTxt5)
    RTPython39.test_support_add_if_parameter_char(goalTxt6)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_setTargetStr7(goalTxt1: str, goalTxt2: str, goalTxt3: str, goalTxt4: str, goalTxt5: str, goalTxt6: str, goalTxt7: str) -> None:
    RTPython39.test_support_create_capl_if_function("Fn_setTargetStr7", 0)
    RTPython39.test_support_add_if_parameter_char(goalTxt1)
    RTPython39.test_support_add_if_parameter_char(goalTxt2)
    RTPython39.test_support_add_if_parameter_char(goalTxt3)
    RTPython39.test_support_add_if_parameter_char(goalTxt4)
    RTPython39.test_support_add_if_parameter_char(goalTxt5)
    RTPython39.test_support_add_if_parameter_char(goalTxt6)
    RTPython39.test_support_add_if_parameter_char(goalTxt7)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_setTargetStr8(goalTxt1: str, goalTxt2: str, goalTxt3: str, goalTxt4: str, goalTxt5: str, goalTxt6: str, goalTxt7: str, goalTxt8: str) -> None:
    RTPython39.test_support_create_capl_if_function("Fn_setTargetStr8", 0)
    RTPython39.test_support_add_if_parameter_char(goalTxt1)
    RTPython39.test_support_add_if_parameter_char(goalTxt2)
    RTPython39.test_support_add_if_parameter_char(goalTxt3)
    RTPython39.test_support_add_if_parameter_char(goalTxt4)
    RTPython39.test_support_add_if_parameter_char(goalTxt5)
    RTPython39.test_support_add_if_parameter_char(goalTxt6)
    RTPython39.test_support_add_if_parameter_char(goalTxt7)
    RTPython39.test_support_add_if_parameter_char(goalTxt8)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_CCU_sleep() -> int16:
    RTPython39.test_support_create_capl_if_function("Fn_CCU_sleep", 0)
    return RTPython39.test_support_call_interface_function_int("", "")
def Fn_CCU_wakeup() -> int16:
    RTPython39.test_support_create_capl_if_function("Fn_CCU_wakeup", 0)
    return RTPython39.test_support_call_interface_function_int("", "")
def Fn_PreDataSentToEachChannel(msg_id: int16, msg_num: uint16, interval: uint16) -> None:
    if msg_id < -32_768 or msg_id > 32_767:
        raise ValueError("msg_id must be in the in the inclusive range (-32_768, 32_767).")
    if msg_num < 0 or msg_num > 65_535:
        raise ValueError("msg_num must be in the in the inclusive range (0, 65_535).")
    if interval < 0 or interval > 65_535:
        raise ValueError("interval must be in the in the inclusive range (0, 65_535).")
    RTPython39.test_support_create_capl_if_function("Fn_PreDataSentToEachChannel", 0)
    RTPython39.test_support_add_if_parameter_int(msg_id)
    RTPython39.test_support_add_if_parameter_word(msg_num)
    RTPython39.test_support_add_if_parameter_word(interval)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_Increase_CANBusLoad(BusLoad_StandardLine: int16, HoldTime: float) -> None:
    if BusLoad_StandardLine < -32_768 or BusLoad_StandardLine > 32_767:
        raise ValueError("BusLoad_StandardLine must be in the in the inclusive range (-32_768, 32_767).")
    RTPython39.test_support_create_capl_if_function("Fn_Increase_CANBusLoad", 0)
    RTPython39.test_support_add_if_parameter_int(BusLoad_StandardLine)
    RTPython39.test_support_add_if_parameter_double(HoldTime)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_tcpdump(COMPortNum: int16, PcapFileName: str) -> None:
    if COMPortNum < -32_768 or COMPortNum > 32_767:
        raise ValueError("COMPortNum must be in the in the inclusive range (-32_768, 32_767).")
    RTPython39.test_support_create_capl_if_function("Fn_tcpdump", 0)
    RTPython39.test_support_add_if_parameter_int(COMPortNum)
    RTPython39.test_support_add_if_parameter_char(PcapFileName)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_EthPressurized_ACore() -> None:
    RTPython39.test_support_create_capl_if_function("Fn_EthPressurized_ACore", 0)
    RTPython39.test_support_call_interface_function("", "", "")
def Fn_EthPressurized_MCore() -> None:
    RTPython39.test_support_create_capl_if_function("Fn_EthPressurized_MCore", 0)
    RTPython39.test_support_call_interface_function("", "", "")


