#!/usr/bin/python
# -*- coding:utf-8 -*-

#Author: Liu Qi
#Version : v1.0

import sys,os,re,can
from collections import Counter

def StrContains(SubStr,Str):
  if SubStr in Str:
    return True
  else:
    return False

def getChnNum(ChnName):
  ChnNum = 0
  
  with open(curr_work_dir + '\\ini\\channel_mapping.ini','r') as chn_mapping_file:
    chn_text = chn_mapping_file.readlines()

  for line in range(len(chn_text)):
    if chn_text[line].split("::")[0] == ChnName:
      ChnNum = int(chn_text[line].split('::')[1])
      break
  
  return(ChnNum)

def getChnName(ChnNum):
  ChnName = ''
  
  with open(curr_work_dir + '\\ini\\channel_mapping.ini','r') as chn_mapping_file:
    chn_text = chn_mapping_file.readlines()

  for line in range(len(chn_text)):
    if int(chn_text[line].split('::')[1]) == ChnNum:
      ChnName = chn_text[line].split('::')[0]
      break

  return(ChnName)

def getdbcMsgData():
  global MsgData_dbc
  MsgData_dbc = []
  dbc_files = [f for f in os.listdir(dbc_folderPath) if f.endswith('.dbc')]

  for dbc_file in dbc_files:
    dbc_file_path = os.path.join(dbc_folderPath, dbc_file)

    with open(dbc_file_path,'r') as file:
      dbc_text = file.readlines()

    for line in range(len(dbc_text)):
      if dbc_text[line][:3] == 'BO_':
        Data_SubArr = []

        first_space = dbc_text[line].find(' ')
        second_space = dbc_text[line].find(' ',first_space + 1)
        third_space = dbc_text[line].find(': ',second_space + 1)

        MsgIDStr = dbc_text[line][first_space + 1:second_space]
        MsgNameStr = dbc_text[line][second_space + 1:third_space]

        Data_SubArr.append(dbc_file[:-4])
        Data_SubArr.append(getChnNum(dbc_file[:-4]))
        Data_SubArr.append(MsgNameStr)
        Data_SubArr.append(MsgIDStr.zfill(4))
    
        MsgData_dbc.append(Data_SubArr)

  return(MsgData_dbc)

def getMsgName(_id,ChnNum):
  MsgName = 'None'

  for i in range(len(MsgData_dbc)):
    if MsgData_dbc[i][3] == _id.zfill(4) and MsgData_dbc[i][1] == ChnNum + 1:
      MsgName = MsgData_dbc[i][2]
      break

  return(MsgName)

def removeArrDupValue(arr):
  return(list(set(arr)))

def getblfMsgData():
  global log_msgname_arr
  log_msgname_arr = []
  getdbcMsgData()
  log_data = can.BLFReader(blf_file)

  for msg in log_data:
    blf_msgname = getMsgName(str(msg.arbitration_id),msg.channel)

    if len(str(msg.arbitration_id)) <= 4 and blf_msgname != 'None':
      log_msgname_arr.append(getChnName(msg.channel + 1) + '::' + blf_msgname)
  
  return(removeArrDupValue(log_msgname_arr))

def getLossMsgData():

  msg_loss_arr = []
  
  if not os.path.exists(curr_work_dir + '\\ini\\CCUSendFrame.ini'):
    print('\n******* The CCUSendFrame.ini file does not exist, please check !!! *******')
  else:

    if not os.path.exists(curr_work_dir + '\\ini\\channel_mapping.ini'):
      print('\n******* The channel_mapping.ini file does not exist, please check !!! *******')
    else:
      getblfMsgData()

      with open(curr_work_dir + '\\ini\\CCUSendFrame.ini','r') as file:
        ini_text = file.readlines()

      for line in range(2,len(ini_text) - 1):
        if not ini_text[line].split(':::')[0] in log_msgname_arr:
          msg_loss_arr.append(ini_text[line].split(':::')[0])
  
  with open(curr_work_dir + '\\log_analysis_result\\-l.txt','w') as result_file:
    result_file.write('******* ' + blf_filename + ' *******\n\n')
    if len(msg_loss_arr) == 0:
      result_file.write('No msg loss !!!')
    else:
      index = 1
      for loss_msg in msg_loss_arr:
        result_file.write(str(index) + '.' + loss_msg + '\n')
        index += 1

def getMsgID(msg):
  MsgIDStr = ''
  dbc_text = open(dbc_folderPath + msg.split('::')[0] + '.dbc','r').readlines()

  for line in range(len(dbc_text)):
    if dbc_text[line][:3] == 'BO_' and StrContains(msg.split('::')[1].split(':::')[0] + ': ',dbc_text[line]):
      first_space = dbc_text[line].find(' ')
      second_space = dbc_text[line].find(' ',first_space + 1)
        
      MsgIDStr = dbc_text[line][first_space + 1:second_space]
      break

  return(MsgIDStr)

def getMsgCycTime(id_str,msg):
  MsgCycTimeStr = ''
  dbc_text = open(dbc_folderPath + msg.split('::')[0] + '.dbc','r').readlines()

  for line in range(len(dbc_text)):
    if StrContains('BA_ "GenMsgCycleTime" BO_ ' + id_str,dbc_text[line]):
      MsgCycTimeStr = dbc_text[line].replace('\n','').split(id_str)[1][1:-1]
      break

  return(MsgCycTimeStr)
  
def log_CycT_Chk(msg_name,_id,channel,cyc_time):

  log_timestamp = []
  log_data = can.BLFReader(blf_file)

  for log_msg in log_data:
    if str(log_msg.arbitration_id) == _id and log_msg.channel == int(channel) - 1:
      log_timestamp.append(log_msg.timestamp)

  with open(curr_work_dir + '\\log_analysis_result\\-p.txt','a') as result_file:
    result_file.write('\n' + msg_name + '['+ cyc_time + 'ms]\n\n')
    
    if len(log_timestamp) == 0:
      result_file.write('No found this msg\n\n')
      return(0)
    else:
      error_num = 0
      for i in range(len(log_timestamp) - 1):
        value = log_timestamp[i + 1] - log_timestamp[i]
        if value > int(cyc_time) / 1000 * 2:
          error_num += 1
          result_file.write(str(error_num) + '.' + str(log_timestamp[i]) + ' ' + str(log_timestamp[i + 1]) + ' ' + str(value) + '\n')

      if error_num == 0:
        result_file.write('Pass\n\n')
        return(1)
      else:
        return(-1)

def log_Counter_Chk(msg_name,_id,channel):
  log_Counter = []
  log_data = can.BLFReader(blf_file)

  for log_msg in log_data:
    if str(log_msg.arbitration_id) == _id and log_msg.channel == int(channel) - 1:
      log_Counter.append(log_msg.data[2])

  with open(curr_work_dir + '\\log_analysis_result\\-p.txt','a') as result_file:
    result_file.write('\n' + msg_name + '\n\n')

    if len(log_Counter) == 0:
      result_file.write('No found this msg\n\n')
      return(0)
    else:
      error_num = 0
      for i in range(len(log_Counter) - 1):
        if (log_Counter[i + 1] != 0 and log_Counter[i + 1] - log_Counter[i] != 1) or (log_Counter[i + 1] == 0 and log_Counter[i] != 255):
          error_num += 1
          result_file.write(str(error_num) + '.' + str(log_Counter[i]) + ' ' + str(log_Counter[i + 1]) + '\n')

      if error_num == 0:
        result_file.write('Pass\n\n')
        return(1)
      else:
        return(-1)

def log_DelayTime_Chk(_id,SrcChn,DestChnStrArr,FrameRoutingChnStrArr):

  CurrID_DataArr = []
  Data_SubArr = []
  Flag = 0
  Msg_Rx_Num = 0
  Msg_num = 0
  log_data = can.BLFReader(blf_file)

  for log_msg in log_data:
    if str(log_msg.arbitration_id) == _id:

      ############# Tx #############
      
      if log_msg.is_rx == False:                  
        if len(Data_SubArr) != 0:
          CurrID_DataArr.append(Data_SubArr)
          Data_SubArr = []
        Data_SubArr.append(log_msg.timestamp)
        Data_SubArr.append(log_msg.channel)
        Flag = 1

      ############# Rx #############

      if log_msg.is_rx == True and Flag == 1:     
        Data_SubArr.append(log_msg.timestamp)
        Data_SubArr.append(log_msg.channel)
        Msg_Rx_Num += 1
    
      Msg_num += 1

  with open(curr_work_dir + '\\log_analysis_result\\-d.txt','a') as result_file:
    result_file.write('\n' + _id + '(' + str(hex(int(_id))) + ')\n')

    if Msg_num == 0:
      result_file.write('No found this msg\n')

    ############  1.Source channel check ############

    if Msg_num != 0:
      CurrID_ErrorSrcChnArr = []

      for data in CurrID_DataArr:
        if data[1] != SrcChn - 1:
          Sub_Arr = []
          Sub_Arr.append(data[0])  #Source timestamp
          Sub_Arr.append(data[1])  #Source channel
          CurrID_ErrorSrcChnArr.append(Sub_Arr)

      if len(CurrID_ErrorSrcChnArr) == 0:
        result_file.write('Check : Source channel [Pass]\n')
      else:
        result_file.write('Check : Source channel [Failed]\n')
        index = 0
        for error_data in CurrID_ErrorSrcChnArr:
          index += 1
          result_file.write(str(index) + '.timestamp : ' + str(error_data[0]) + ' error_source_channel : ' + str(error_data[1]) + '\n')

    ############ 2.No Routing check ############

    if Msg_num != 0:
      if Msg_Rx_Num == 0:
        result_file.write('Check : No Routing [Failed] --> Not routed to any channel,Not tested.\n')
      else:
        CurrID_NoRouting = []
        for data in CurrID_DataArr:
          if len(data) == 2:
            Sub_Arr = []
            Sub_Arr.append(data[0])
            Sub_Arr.append(data[1])
            CurrID_NoRouting.append(Sub_Arr)

        if len(CurrID_NoRouting) == 0:
          result_file.write('Check : No Routing [Pass]\n')
        else:
          result_file.write('Check : No Routing [Failed]\n')
          index = 0
          for error_data in CurrID_NoRouting:
            index += 1
            result_file.write(str(index) + '.timestamp : ' + str(error_data[0]) + ' source_channel : ' + str(error_data[1]) + '\n')

    ############ 3.Error Routing check ############

    if Msg_num != 0:
      if Msg_Rx_Num == 0:
        result_file.write('Check : Error Routing [Failed] --> Not routed to any channel,Not tested.\n')
      else:
        CurrID_ErrorRouting = []
        for data in CurrID_DataArr:
          for i in range(2,len(data)):
            if i % 2 == 1:
              CurrMsgName = getChnName(data[i]+1)
              if not CurrMsgName in DestChnStrArr and not CurrMsgName in FrameRoutingChnStrArr:
                Sub_Arr = []
                Sub_Arr.append(data[i-1])
                Sub_Arr.append(getChnName(data[i]+1))
                CurrID_ErrorRouting.append(Sub_Arr)

        if len(CurrID_ErrorRouting) == 0:
          result_file.write('Check : Error Routing [Pass]\n')
        else:
          result_file.write('Check : Error Routing [Failed]\n')
          index = 0
          for error_data in CurrID_ErrorRouting:
            index += 1
            result_file.write(str(index) + '.timestamp : ' + str(error_data[0]) + ' error_routing_channel : ' + error_data[1] + '\n')

    ############ 4.Loss Routing check ############

    if Msg_num != 0:
      if Msg_Rx_Num == 0:
        result_file.write('Check : Loss Routing [Failed] --> Not routed to any channel,Not tested.\n')
      else:
        CurrID_LossRouting = []
        for data in CurrID_DataArr:
          AcChnArr = []
          for i in range(2,len(data)):
            if i % 2 == 1:
              AcChnArr.append(data[i])
 
          for DestChnStr in DestChnStrArr:
            if not getChnNum(DestChnStr) - 1 in AcChnArr:
              Sub_Arr = []
              Sub_Arr.append(data[0])
              Sub_Arr.append(DestChnStr)
              CurrID_LossRouting.append(Sub_Arr)

        if len(CurrID_LossRouting) == 0:
          result_file.write('Check : Loss Routing [Pass]\n')
        else:
          result_file.write('Check : Loss Routing [Failed]\n')
          index = 0
          for error_data in CurrID_LossRouting:
            index += 1
            result_file.write(str(index) + '.source_timestamp : ' + str(error_data[0]) + ' loss_routing_channel : ' + error_data[1] + '\n')

    ############ 5.Duplicate Routing check ############

    if Msg_num != 0:
      if Msg_Rx_Num == 0:
        result_file.write('Check : Duplicate Routing [Failed] --> Not routed to any channel,Not tested.\n')
      else:
        CurrID_DupRouting = []
        for data in CurrID_DataArr:
          AcChnArr = []
          for i in range(2,len(data)):
            if i % 2 == 1:
              AcChnArr.append(data[i])

          counts = Counter(AcChnArr)
          duplicates = [num for num, count in counts.items() if count > 1]

          if len(duplicates) != 0:
            Sub_Arr = []
            Sub_Arr.append(data[0])
            for chn in duplicates:
              ChnName = getChnName(chn+1)
              Sub_Arr.append(ChnName)
              CurrID_DupRouting.append(Sub_Arr)

        if len(CurrID_DupRouting) == 0:
          result_file.write('Check : Duplicate Routing [Pass]\n')
        else:
          result_file.write('Check : Duplicate Routing [Failed]\n')
          index = 0
          for error_data in CurrID_DupRouting:
            index += 1
            result_file.write(str(index) + '.source_timestamp : ' + str(error_data[0]) + ' duplicate_routing_channel : ' + str(error_data[1:len(error_data)]) + '\n')

    ############ 6.delaytime check ############

    if Msg_num != 0:
      if Msg_Rx_Num == 0:
        result_file.write('Check : delaytime <= 1ms(0.001s) [Failed] --> Not routed to any channel,Not tested.\n')
      else:
        CurrID_DelayTime = []
        for data in CurrID_DataArr:
          for i in range(2,len(data)):
            if i % 2 == 0:
              if data[i] - data[0] > 0.001:
                Sub_Arr = []
                Sub_Arr.append(data[0]) # source channel timestamp
                Sub_Arr.append(getChnName(data[1]+1)) # source channel name
                Sub_Arr.append(data[i]) # dest channel timestamp
                Sub_Arr.append(getChnName(data[i+1]+1)) # dest channel name
                Sub_Arr.append(round(data[i] - data[0],6)) # delay time
                CurrID_DelayTime.append(Sub_Arr)

        if len(CurrID_DelayTime) == 0:
          result_file.write('Check : delaytime <= 1ms(0.001s) [Pass]\n')
        else:
          result_file.write('Check : delaytime <= 1ms(0.001s) [Failed]\n')
          index = 0
          for error_data in CurrID_DelayTime:
            index += 1
            result_file.write(str(index) + '.source_timestamp : ' + str(error_data[0]) + ' SrcChn : ' + error_data[1] + ' dest_timestamp : ' + str(error_data[2]) + ' DestChn : ' + error_data[3] + ' delaytime : ' + str(error_data[4]) + '\n')

def PacketLoss_check():

  if not os.path.exists(curr_work_dir + '\\ini\\CCUSendFrame.ini'):
    print('\n******* The CCUSendFrame.ini file does not exist, please check !!! *******')
  else:

    Total_num = 0
    No_msg_num = 0
    Pass_num = 0
    Fail_num = 0

    ChkCycT_msgArr = []
    Counter_msgArr = []

    with open(curr_work_dir + '\\ini\\CCUSendFrame.ini','r') as file:
      ini_text = file.readlines()

    for line in range(2,len(ini_text) - 1):
      if ini_text[line].split(':::')[1].replace('\n','') == 'CycTime':
        ChkCycT_msgArr.append(ini_text[line].split(':::')[0])
      else:
        Counter_msgArr.append(ini_text[line].split(':::')[0])

    with open(curr_work_dir + '\\log_analysis_result\\-p.txt','w') as result_file:
      result_file.write('******* ' + blf_filename + ' *******\n')

    for msg in ChkCycT_msgArr:
      CurrMsgChnNum = getChnNum(msg.split('::')[0])
      CurrMsgID = getMsgID(msg)
      CurrMsgCycTime = getMsgCycTime(CurrMsgID,msg)
      retVal = log_CycT_Chk(msg,CurrMsgID,CurrMsgChnNum,CurrMsgCycTime)

      if retVal == 0:
        No_msg_num += 1
      elif retVal == 1:
        Pass_num += 1
      else:
        Fail_num += 1
    
    for msg in Counter_msgArr:
      CurrMsgChnNum = getChnNum(msg.split('::')[0])
      CurrMsgID = getMsgID(msg)
      retVal = log_Counter_Chk(msg,CurrMsgID,CurrMsgChnNum)

      if retVal == 0:
        No_msg_num += 1
      elif retVal == 1:
        Pass_num += 1
      else:
        Fail_num += 1

    with open(curr_work_dir + '\\log_analysis_result\\-p.txt','a') as result_file:
      Total_num = len(ChkCycT_msgArr) + len(Counter_msgArr)
      result_file.write('*** Total : ' + str(Total_num) + ' No_msg : ' + str(No_msg_num) + ' Pass : ' + str(Pass_num) + ' Failed : ' + str(Fail_num) + ' ***\n')
      
def DelayTime_check():

  if not os.path.exists(curr_work_dir + '\\ini\\RoutingChart.ini'):
    print('\n******* The RoutingChart.ini file does not exist, please check !!! *******')
  else:
    RoutingChartDataArr = []
    frame_routingchn_StrArr = []

    with open(curr_work_dir + '\\ini\\RoutingChart.ini','r') as ini_file:
      ini_text = ini_file.readlines()

    for line in range(2,len(ini_text)):
      RoutingChartDataArr.append(ini_text[line].replace('\n','').split('-->')[0].split('::'))
      frame_routingchn_StrArr.append(ini_text[line].replace('\n','').split('-->')[1].split('::'))

    with open(curr_work_dir + '\\log_analysis_result\\-d.txt','w') as result_file:
      result_file.write('******* ' + blf_filename + ' *******\n')

    index = 0

    for Data in RoutingChartDataArr:
      msg_id = str(int(Data[0][2:],16))
      msg_source_channel = getChnNum(Data[1])
      msg_dest_channel_arr = []

      for i in range(2,len(Data)):
        msg_dest_channel_arr.append(Data[i])

      log_DelayTime_Chk(msg_id,msg_source_channel,msg_dest_channel_arr,frame_routingchn_StrArr[index])
      index += 1

def main():
  Mode = sys.argv[1]

  global curr_work_dir
  global blf_filename
  global dbc_folderPath
  global blf_file

  blf_file = sys.argv[2]
  curr_work_dir = os.path.dirname(__file__)
  blf_filename = re.sub('[\u4e00-\u9fa5]','',os.path.basename(blf_file))
  dbc_folderPath = curr_work_dir + '\\Databases\\'

  if Mode == '-l':
    getLossMsgData()
    print('\n********** SUCCESS !!! **********')
  elif Mode == '-p':
    PacketLoss_check()
    print('\n********** SUCCESS !!! **********')
  elif Mode == '-d':
    DelayTime_check()
    print('\n********** SUCCESS !!! **********')
  else:
    print("\n******* Prompt : parameter error,only '-l','-p' or '-d' is supported !!! *******")

if __name__ == '__main__':
  main()
