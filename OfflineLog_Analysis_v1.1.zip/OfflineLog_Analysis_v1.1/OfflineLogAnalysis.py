#!/usr/bin/python
# -*- coding:utf-8 -*-

#Author: Liu Qi
Version = 'V1.1'

import sys,os,re,can,openpyxl
from collections import Counter
from openpyxl import Workbook
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment
from openpyxl import load_workbook
from openpyxl.styles import PatternFill,Border,Side

def CreateFolder(FolderName):
  FolderPath = curr_work_dir + '/' + FolderName
  if not os.path.exists(FolderPath):
    os.mkdir(curr_work_dir + '/' + FolderName)

def StrContains(SubStr,Str):
  if SubStr in Str:
    return True
  else:
    return False

def getChnNum(ChnName):
  ChnNum = 0
  
  with open(curr_work_dir + '\\ini\\channel_mapping.ini','r') as chn_mapping_file:
    chn_text = chn_mapping_file.readlines()

  for line in range(len(chn_text)):
    if chn_text[line].split("::")[0] == ChnName:
      ChnNum = int(chn_text[line].split('::')[1])
      break
  
  return(ChnNum)

def getChnName(ChnNum):
  ChnName = ''
  
  with open(curr_work_dir + '\\ini\\channel_mapping.ini','r') as chn_mapping_file:
    chn_text = chn_mapping_file.readlines()

  for line in range(len(chn_text)):
    if int(chn_text[line].split('::')[1]) == ChnNum:
      ChnName = chn_text[line].split('::')[0]
      break

  return(ChnName)

def getdbcMsgData():
  print('1.Get dbc data !!!')
  global MsgData_dbc
  MsgData_dbc = []
  dbc_files = [f for f in os.listdir(dbc_folderPath) if f.endswith('.dbc')]

  for dbc_file in dbc_files:
    dbc_file_path = os.path.join(dbc_folderPath, dbc_file)

    with open(dbc_file_path,'r') as file:
      dbc_text = file.readlines()

    for line in range(len(dbc_text)):
      if dbc_text[line][:3] == 'BO_':
        Data_SubArr = []

        first_space = dbc_text[line].find(' ')
        second_space = dbc_text[line].find(' ',first_space + 1)
        third_space = dbc_text[line].find(': ',second_space + 1)

        MsgIDStr = dbc_text[line][first_space + 1:second_space]
        MsgNameStr = dbc_text[line][second_space + 1:third_space]

        Data_SubArr.append(dbc_file[:-4])
        Data_SubArr.append(getChnNum(dbc_file[:-4]))
        Data_SubArr.append(MsgNameStr)
        Data_SubArr.append(MsgIDStr.zfill(4))
    
        MsgData_dbc.append(Data_SubArr)

  return(MsgData_dbc)

def getMsgName(_id,ChnNum):
  MsgName = 'None'

  for i in range(len(MsgData_dbc)):
    if MsgData_dbc[i][3] == _id.zfill(4) and MsgData_dbc[i][1] == ChnNum + 1:
      MsgName = MsgData_dbc[i][2]
      break

  return(MsgName)

def removeArrDupValue(arr):
  return(list(set(arr)))

def getblfMsgData():
  global log_msgname_arr
  log_msgname_arr = []
  getdbcMsgData()
  log_data = can.BLFReader(blf_file)

  print('2.Get .blf file log data')

  for msg in log_data:
    blf_msgname = getMsgName(str(msg.arbitration_id),msg.channel)

    if len(str(msg.arbitration_id)) <= 4 and blf_msgname != 'None':
      log_msgname_arr.append(getChnName(msg.channel + 1) + '::' + blf_msgname)
  
  return(removeArrDupValue(log_msgname_arr))

def getLossMsgData():

  msg_loss_arr = []
  
  if not os.path.exists(curr_work_dir + '\\ini\\CCUSendFrame.ini'):
    print('\n******* The CCUSendFrame.ini file does not exist, please check !!! *******')
  else:

    if not os.path.exists(curr_work_dir + '\\ini\\channel_mapping.ini'):
      print('\n******* The channel_mapping.ini file does not exist, please check !!! *******')
    else:
      getblfMsgData()

      with open(curr_work_dir + '\\ini\\CCUSendFrame.ini','r') as file:
        ini_text = file.readlines()
      
      print('3.In data analysis...')

      for line in range(2,len(ini_text) - 1):
        if not ini_text[line].split(':::')[0] in log_msgname_arr:
          msg_loss_arr.append(ini_text[line].split(':::')[0])

  xlsx_workbook = Workbook()
  sheet = xlsx_workbook.active

  print('4.Start write data in msg_loss.xlsx\n')

  if len(msg_loss_arr) == 0:
    sheet.cell(row=1,column=1,value='No msg loss').alignment = Alignment(horizontal='center', vertical='center')
    sheet.cell(row=1,column=1).border = Border(left=Side(style='thin'),right=Side(style='thin'),top=Side(style='thin'),bottom=Side(style='thin'))
    sheet.column_dimensions['A'].width = 15
  else:
    index = 1
    sheet.cell(row=1,column=1,value='No.').alignment = Alignment(horizontal='center', vertical='center')
    sheet.cell(row=1,column=1).fill = PatternFill(start_color='BCD2EE', end_color='BCD2EE', fill_type='solid')
    sheet.column_dimensions['A'].width = 10
    sheet.cell(row=1,column=1).border = Border(left=Side(style='thin'),right=Side(style='thin'),top=Side(style='thin'),bottom=Side(style='thin'))

    sheet.cell(row=1,column=2,value='Message loss').alignment = Alignment(horizontal='center', vertical='center')
    sheet.cell(row=1,column=2).fill = PatternFill(start_color='BCD2EE', end_color='BCD2EE', fill_type='solid')
    sheet.column_dimensions['B'].width = 30
    sheet.cell(row=1,column=2).border = Border(left=Side(style='thin'),right=Side(style='thin'),top=Side(style='thin'),bottom=Side(style='thin'))

    for loss_msg in msg_loss_arr:
      sheet.cell(row=index+1,column=1,value=str(index)).alignment = Alignment(horizontal='center', vertical='center')
      sheet.cell(row=index+1,column=2,value=loss_msg).alignment = Alignment(horizontal='center', vertical='center')
      sheet.cell(row=index+1,column=1).border = Border(left=Side(style='thin'),right=Side(style='thin'),top=Side(style='thin'),bottom=Side(style='thin'))
      sheet.cell(row=index+1,column=2).border = Border(left=Side(style='thin'),right=Side(style='thin'),top=Side(style='thin'),bottom=Side(style='thin'))
      index += 1
  
  xlsx_workbook.save(curr_work_dir + '\\log_analysis_result\\msg_loss.xlsx')

def getMsgID(msg):
  MsgIDStr = ''
  dbc_text = open(dbc_folderPath + msg.split('::')[0] + '.dbc','r').readlines()

  for line in range(len(dbc_text)):
    if dbc_text[line][:3] == 'BO_' and StrContains(msg.split('::')[1].split(':::')[0] + ': ',dbc_text[line]):
      first_space = dbc_text[line].find(' ')
      second_space = dbc_text[line].find(' ',first_space + 1)
        
      MsgIDStr = dbc_text[line][first_space + 1:second_space]
      break

  return(MsgIDStr)

def getMsgCycTime(id_str,msg):
  MsgCycTimeStr = ''
  dbc_text = open(dbc_folderPath + msg.split('::')[0] + '.dbc','r').readlines()

  for line in range(len(dbc_text)):
    if StrContains('BA_ "GenMsgCycleTime" BO_ ' + id_str,dbc_text[line]):
      MsgCycTimeStr = dbc_text[line].replace('\n','').split(id_str)[1][1:-1]
      break

  return(MsgCycTimeStr)
  
def log_CycT_Chk(_id,channel,cyc_time,error_arr,ChnName_str,MsgName_str):

  log_timestamp = []

  for log_msg in LogData_Arr:
    if str(log_msg[1]) == _id and log_msg[4] == int(channel) - 1:
      log_timestamp.append(log_msg[0])

  if len(log_timestamp) == 0:
    return(0)
  else:
    error_num = 0
    for i in range(len(log_timestamp) - 1):
      value = log_timestamp[i + 1] - log_timestamp[i]
      if value > int(cyc_time) / 1000 * 2:
        error_num += 1
        error_sub_arr = []
        error_sub_arr.append(ChnName_str)
        error_sub_arr.append(MsgName_str)
        error_sub_arr.append('Cyc[' + cyc_time + 'ms]')
        error_sub_arr.append(str(log_timestamp[i]))
        error_sub_arr.append(str(log_timestamp[i + 1]))
        error_sub_arr.append(str(value))
        error_sub_arr.append('/')
        error_sub_arr.append('/')
        error_sub_arr.append('/')
        error_arr.append(error_sub_arr)

    if error_num == 0:
      return(1)
    else:
      return(-1)

def log_Counter_Chk(_id,channel,error_arr,ChnName_str,MsgName_str):
  log_Counter = []

  for log_msg in LogData_Arr:
    if str(log_msg[1]) == _id and log_msg[4] == int(channel) - 1:
      log_Counter.append(log_msg[3])

  if len(log_Counter) == 0:
    return(0)
  else:
    error_num = 0
    for i in range(len(log_Counter) - 1):
      if (log_Counter[i + 1] != 0 and log_Counter[i + 1] - log_Counter[i] != 1) or (log_Counter[i + 1] == 0 and log_Counter[i] != 255):
        error_num += 1
        error_sub_arr = []
        error_sub_arr.append(ChnName_str)
        error_sub_arr.append(MsgName_str)
        error_sub_arr.append('Counter')
        error_sub_arr.append('/')
        error_sub_arr.append('/')
        error_sub_arr.append('/')
        error_sub_arr.append(str(log_Counter[i]))
        error_sub_arr.append(str(log_Counter[i + 1]))

        if log_Counter[i + 1] != 0:
          value = log_Counter[i + 1] - log_Counter[i]
          error_sub_arr.append(str(value))
        else:
          if log_Counter[i] != 0:
            value = log_Counter[i + 1] + 256 - log_Counter[i]
            error_sub_arr.append(str(value))
          else:
            error_sub_arr.append('counter error')

        error_arr.append(error_sub_arr)

    if error_num == 0:
      return(1)
    else:
      return(-1)

def log_DelayTime_Chk(_id,SrcChn,DestChnStrArr,FrameRoutingChnStrArr,error_arr):

  result_Sub_arr = []
  CurrID_DataArr = []
  Data_SubArr = []
  Flag = 0
  Msg_Rx_Num = 0
  Msg_num = 0

  for log_msg in LogData_Arr:
    if str(log_msg[1]) == _id:

      ############# Tx #############
      
      if log_msg[2] == False:                  
        if len(Data_SubArr) != 0:
          CurrID_DataArr.append(Data_SubArr)
          Data_SubArr = []
        Data_SubArr.append(log_msg[0])
        Data_SubArr.append(log_msg[4])
        Flag = 1

      ############# Rx #############

      if log_msg[2] == True and Flag == 1:     
        Data_SubArr.append(log_msg[0])
        Data_SubArr.append(log_msg[4])
        Msg_Rx_Num += 1
    
      Msg_num += 1

  if Msg_num == 0:
    for i in range(6):
      result_Sub_arr.append('NT')
    result_Sub_arr.append('No found this msg')

  ############  1.Source channel check ############

  if Msg_num != 0:
    CurrID_ErrorSrcChnArr = []
    for data in CurrID_DataArr:
      if data[1] != SrcChn - 1:
        Sub_Arr = []
        Sub_Arr.append(data[0])  #Source timestamp
        Sub_Arr.append(data[1])  #Source channel
        CurrID_ErrorSrcChnArr.append(Sub_Arr)

    if len(CurrID_ErrorSrcChnArr) == 0:
      result_Sub_arr.append('Pass')
    else:
      result_Sub_arr.append('Failed')
      for error_data in CurrID_ErrorSrcChnArr:
        error_sub_arr = []
        error_sub_arr.append(str(hex(int(_id))))
        error_sub_arr.append('SrcChn Error')
        error_sub_arr.append(str(error_data[0]))
        error_sub_arr.append(str(error_data[1]))
        error_sub_arr.append('/')
        error_sub_arr.append('/')
        error_sub_arr.append('/')
        error_sub_arr.append('/')
        error_sub_arr.append('/')
        error_sub_arr.append('/')
        error_sub_arr.append('/')
        error_arr.append(error_sub_arr)

  ############ 2.No Routing check ############

  if Msg_num != 0:
    if Msg_Rx_Num == 0:
      result_Sub_arr.append('NT')
    else:
      CurrID_NoRouting = []
      for data in CurrID_DataArr:
        if len(data) == 2:
          Sub_Arr = []
          Sub_Arr.append(data[0])
          Sub_Arr.append(data[1])
          CurrID_NoRouting.append(Sub_Arr)

      if len(CurrID_NoRouting) == 0:
        result_Sub_arr.append('Pass')
      else:
        result_Sub_arr.append('Failed')
        for error_data in CurrID_NoRouting:
          error_sub_arr = []
          error_sub_arr.append(str(hex(int(_id))))
          error_sub_arr.append('NoRouting')
          error_sub_arr.append(str(error_data[0]))
          error_sub_arr.append(str(error_data[1]))
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_arr.append(error_sub_arr)

  ############ 3.Error Routing check ############

  if Msg_num != 0:
    if Msg_Rx_Num == 0:
      result_Sub_arr.append('NT')
    else:
      CurrID_ErrorRouting = []
      for data in CurrID_DataArr:
        for i in range(2,len(data)):
          if i % 2 == 1:
            CurrMsgName = getChnName(data[i]+1)
            if not CurrMsgName in DestChnStrArr and not CurrMsgName in FrameRoutingChnStrArr:
              Sub_Arr = []
              Sub_Arr.append(data[i-1])
              Sub_Arr.append(getChnName(data[i]+1))
              CurrID_ErrorRouting.append(Sub_Arr)

      if len(CurrID_ErrorRouting) == 0:
        result_Sub_arr.append('Pass')
      else:
        result_Sub_arr.append('Failed')
        for error_data in CurrID_ErrorRouting:
          error_sub_arr = []
          error_sub_arr.append(str(hex(int(_id))))
          error_sub_arr.append('ErrorRouting')
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append(str(error_data[0]))
          error_sub_arr.append(error_data[1])
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_arr.append(error_sub_arr)

  ############ 4.Loss Routing check ############

  if Msg_num != 0:
    if Msg_Rx_Num == 0:
      result_Sub_arr.append('NT')
    else:
      CurrID_LossRouting = []
      for data in CurrID_DataArr:
        AcChnArr = []
        for i in range(2,len(data)):
          if i % 2 == 1:
            AcChnArr.append(data[i])
 
        for DestChnStr in DestChnStrArr:
          if not getChnNum(DestChnStr) - 1 in AcChnArr:
            Sub_Arr = []
            Sub_Arr.append(data[0])
            Sub_Arr.append(DestChnStr)
            CurrID_LossRouting.append(Sub_Arr)

      if len(CurrID_LossRouting) == 0:
        result_Sub_arr.append('Pass')
      else:
        result_Sub_arr.append('Failed')
        for error_data in CurrID_LossRouting:
          error_sub_arr = []
          error_sub_arr.append(str(hex(int(_id))))
          error_sub_arr.append('LossRouting')
          error_sub_arr.append(str(error_data[0]))
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append(error_data[1])
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_arr.append(error_sub_arr)

  ############ 5.Duplicate Routing check ############

  if Msg_num != 0:
    if Msg_Rx_Num == 0:
      result_Sub_arr.append('NT')
    else:
      CurrID_DupRouting = []
      for data in CurrID_DataArr:
        AcChnArr = []
        for i in range(2,len(data)):
          if i % 2 == 1:
            AcChnArr.append(data[i])

        counts = Counter(AcChnArr)
        duplicates = [num for num, count in counts.items() if count > 1]

        if len(duplicates) != 0:
          Sub_Arr = []
          Sub_Arr.append(data[0])
          for chn in duplicates:
            ChnName = getChnName(chn+1)
            Sub_Arr.append(ChnName)
            CurrID_DupRouting.append(Sub_Arr)

      if len(CurrID_DupRouting) == 0:
        result_Sub_arr.append('Pass')
      else:
        result_Sub_arr.append('Failed')
        for error_data in CurrID_DupRouting:
          error_sub_arr = []
          error_sub_arr.append(str(hex(int(_id))))
          error_sub_arr.append('DupRouting')
          error_sub_arr.append(str(error_data[0]))
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append(str(error_data[1:len(error_data)]))
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_arr.append(error_sub_arr)

  ############ 6.delaytime check ############

  if Msg_num != 0:
    if Msg_Rx_Num == 0:
      result_Sub_arr.append('NT')
    else:
      CurrID_DelayTime = []
      for data in CurrID_DataArr:
        for i in range(2,len(data)):
          if i % 2 == 0:
            if data[i] - data[0] > 0.001:
              Sub_Arr = []
              Sub_Arr.append(data[0]) # source channel timestamp
              Sub_Arr.append(getChnName(data[1]+1)) # source channel name
              Sub_Arr.append(data[i]) # dest channel timestamp
              Sub_Arr.append(getChnName(data[i+1]+1)) # dest channel name
              Sub_Arr.append(round(data[i] - data[0],6)) # delay time
              CurrID_DelayTime.append(Sub_Arr)

      if len(CurrID_DelayTime) == 0:
        result_Sub_arr.append('Pass')
      else:
        result_Sub_arr.append('Failed')
        for error_data in CurrID_DelayTime:
          error_sub_arr = []
          error_sub_arr.append(str(hex(int(_id))))
          error_sub_arr.append('DelayTimeError')
          error_sub_arr.append(str(error_data[0]))
          error_sub_arr.append(error_data[1])
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append('/')
          error_sub_arr.append(str(error_data[2]))
          error_sub_arr.append(error_data[3])
          error_sub_arr.append(str(error_data[4]))
          error_arr.append(error_sub_arr)

  RemarkStr = ''
  if Msg_Rx_Num == 0 and Msg_num != 0:
    RemarkStr = 'Not routed to any channel'
  
  if Msg_num != 0:
    result_Sub_arr.append(RemarkStr)

  return(result_Sub_arr)

def PacketLoss_check():

  if not os.path.exists(curr_work_dir + '\\ini\\CCUSendFrame.ini'):
    print('\n******* The CCUSendFrame.ini file does not exist, please check !!! *******')
  else:
    msg_index = 1

    ChkCycT_msgArr = []
    Counter_msgArr = []
    error_data_str_arr = []

    with open(curr_work_dir + '\\ini\\CCUSendFrame.ini','r') as file:
      ini_text = file.readlines()

    for line in range(2,len(ini_text) - 1):
      if ini_text[line].split(':::')[1].replace('\n','') == 'CycTime':
        ChkCycT_msgArr.append(ini_text[line].split(':::')[0])
      else:
        Counter_msgArr.append(ini_text[line].split(':::')[0])

    FirstRowsArr = ['No.','Channel','Msg Name','Msg type','Result','Remark']
    xlsx_workbook = Workbook()
    sheet = xlsx_workbook.active
    sheet.title = 'Summary'

    sheet.column_dimensions['A'].width = 10
    sheet.column_dimensions['B'].width = 20
    sheet.column_dimensions['C'].width = 15
    sheet.column_dimensions['D'].width = 20
    sheet.column_dimensions['E'].width = 15
    sheet.column_dimensions['F'].width = 25

    for i in range(len(FirstRowsArr)):
      sheet.cell(row=1,column=i+1,value=FirstRowsArr[i]).alignment = Alignment(horizontal='center', vertical='center')
      sheet.cell(row=1,column=i+1).border = Border(left=Side(style='thin'),right=Side(style='thin'),top=Side(style='thin'),bottom=Side(style='thin'))

    for column in range(1,len(FirstRowsArr)+1):
      sheet.cell(row=1, column=column).fill = PatternFill(start_color='BCD2EE', end_color='BCD2EE', fill_type='solid')

    for msg in ChkCycT_msgArr:
      CurrMsgChnNum = getChnNum(msg.split('::')[0])
      CurrMsgID = getMsgID(msg)
      CurrMsgCycTime = getMsgCycTime(CurrMsgID,msg)
      retVal = log_CycT_Chk(CurrMsgID,CurrMsgChnNum,CurrMsgCycTime,error_data_str_arr,msg.split('::')[0],msg.split('::')[1])

      CurrTestResult = ''
      RemarkStr = ''

      if retVal == 0:
        CurrTestResult = 'NT'
        RemarkStr = 'No found this msg'
      elif retVal == 1:
        CurrTestResult = 'Pass'
        RemarkStr = ''
      else:
        CurrTestResult = 'Failed'
        RemarkStr = 'PacketLoss'

      sheet.cell(row=msg_index+1,column=1,value=str(msg_index)).alignment = Alignment(horizontal='center', vertical='center')
      sheet.cell(row=msg_index+1,column=2,value=msg.split('::')[0]).alignment = Alignment(horizontal='center', vertical='center')
      sheet.cell(row=msg_index+1,column=3,value=msg.split('::')[1]).alignment = Alignment(horizontal='center', vertical='center')
      sheet.cell(row=msg_index+1,column=4,value='Cyc[' + CurrMsgCycTime + 'ms]').alignment = Alignment(horizontal='center', vertical='center')
      sheet.cell(row=msg_index+1,column=5,value=CurrTestResult).alignment = Alignment(horizontal='center', vertical='center')

      if CurrTestResult == 'NT':
        sheet.cell(row=msg_index+1, column=5).fill = PatternFill(start_color='ADADAD', end_color='ADADAD', fill_type='solid')
      elif CurrTestResult == 'Failed':
        sheet.cell(row=msg_index+1, column=5).fill = PatternFill(start_color='FF5809', end_color='FF5809', fill_type='solid')
      elif CurrTestResult == 'Pass':
        sheet.cell(row=msg_index+1, column=5).fill = PatternFill(start_color='B7FF4A', end_color='B7FF4A', fill_type='solid')

      sheet.cell(row=msg_index+1,column=6,value=RemarkStr).alignment = Alignment(horizontal='center', vertical='center')
      
      for i in range(len(FirstRowsArr)):
        sheet.cell(row=msg_index+1,column=i+1).border = Border(left=Side(style='thin'),right=Side(style='thin'),top=Side(style='thin'),bottom=Side(style='thin'))
      
      print(str(round(msg_index/(len(ChkCycT_msgArr)+len(Counter_msgArr))*100,2)) + '%')
      msg_index += 1

    
    for msg in Counter_msgArr:
      CurrMsgChnNum = getChnNum(msg.split('::')[0])
      CurrMsgID = getMsgID(msg)
      retVal = log_Counter_Chk(CurrMsgID,CurrMsgChnNum,error_data_str_arr,msg.split('::')[0],msg.split('::')[1])

      CurrTestResult = ''
      RemarkStr = ''

      if retVal == 0:
        CurrTestResult = 'NT'
        RemarkStr = 'No found this msg'
      elif retVal == 1:
        CurrTestResult = 'Pass'
        RemarkStr = ''
      else:
        CurrTestResult = 'Failed'
        RemarkStr = 'PacketLoss'

      sheet.cell(row=msg_index+1,column=1,value=str(msg_index)).alignment = Alignment(horizontal='center', vertical='center')
      sheet.cell(row=msg_index+1,column=2,value=msg.split('::')[0]).alignment = Alignment(horizontal='center', vertical='center')
      sheet.cell(row=msg_index+1,column=3,value=msg.split('::')[1]).alignment = Alignment(horizontal='center', vertical='center')
      sheet.cell(row=msg_index+1,column=4,value='Counter').alignment = Alignment(horizontal='center', vertical='center')
      sheet.cell(row=msg_index+1,column=5,value=CurrTestResult).alignment = Alignment(horizontal='center', vertical='center')

      if CurrTestResult == 'NT':
        sheet.cell(row=msg_index+1, column=5).fill = PatternFill(start_color='ADADAD', end_color='ADADAD', fill_type='solid')
      elif CurrTestResult == 'Failed':
        sheet.cell(row=msg_index+1, column=5).fill = PatternFill(start_color='FF5809', end_color='FF5809', fill_type='solid')
      elif CurrTestResult == 'Pass':
        sheet.cell(row=msg_index+1, column=5).fill = PatternFill(start_color='B7FF4A', end_color='B7FF4A', fill_type='solid')

      sheet.cell(row=msg_index+1,column=6,value=RemarkStr).alignment = Alignment(horizontal='center', vertical='center')

      for i in range(6):
        sheet.cell(row=msg_index+1,column=i+1).border = Border(left=Side(style='thin'),right=Side(style='thin'),top=Side(style='thin'),bottom=Side(style='thin'))

      print(str(round(msg_index/(len(ChkCycT_msgArr)+len(Counter_msgArr))*100,2)) + '%')
      msg_index += 1

    if len(error_data_str_arr) != 0:
      error_data_sheet = xlsx_workbook.create_sheet(title='Error Data')

      error_data_sheet.column_dimensions['A'].width = 20
      error_data_sheet.column_dimensions['B'].width = 15
      error_data_sheet.column_dimensions['C'].width = 15
      error_data_sheet.column_dimensions['D'].width = 20
      error_data_sheet.column_dimensions['E'].width = 20
      error_data_sheet.column_dimensions['F'].width = 25
      error_data_sheet.column_dimensions['G'].width = 15
      error_data_sheet.column_dimensions['H'].width = 15
      error_data_sheet.column_dimensions['I'].width = 20

      FirstRowsArr = ['Channel','Msg Name','Msg Type','timestamp_start','timestamp_end','timestamp difference','counter_start','counter_end','counter difference']

      for i in range(len(FirstRowsArr)):
        error_data_sheet.cell(row=1,column=i+1,value=FirstRowsArr[i]).alignment = Alignment(horizontal='center', vertical='center')
        error_data_sheet.cell(row=1,column=i+1).border = Border(left=Side(style='thin'),right=Side(style='thin'),top=Side(style='thin'),bottom=Side(style='thin'))
 
      for column in range(1,len(FirstRowsArr)+1):
        error_data_sheet.cell(row=1, column=column).fill = PatternFill(start_color='BCD2EE', end_color='BCD2EE', fill_type='solid')

      for x in range(len(error_data_str_arr)):
        for y in range(len(error_data_str_arr[x])):
          error_data_sheet.cell(row=x+2,column=y+1,value=error_data_str_arr[x][y]).alignment = Alignment(horizontal='center', vertical='center')
          error_data_sheet.cell(row=x+2,column=y+1).border = Border(left=Side(style='thin'),right=Side(style='thin'),top=Side(style='thin'),bottom=Side(style='thin'))

    xlsx_workbook.save(curr_work_dir + '\\log_analysis_result\\PktLossChk.xlsx')

def DelayTime_check():

  if not os.path.exists(curr_work_dir + '\\ini\\RoutingChart.ini'):
    print('\n******* The RoutingChart.ini file does not exist, please check !!! *******')
  else:
    RoutingChartDataArr = []
    frame_routingchn_StrArr = []
    result_arr = []
    error_data_str_arr = []

    with open(curr_work_dir + '\\ini\\RoutingChart.ini','r') as ini_file:
      ini_text = ini_file.readlines()

    for line in range(2,len(ini_text)):
      RoutingChartDataArr.append(ini_text[line].replace('\n','').split('-->')[0].split('::'))
      frame_routingchn_StrArr.append(ini_text[line].replace('\n','').split('-->')[1].split('::'))

    index = 0

    for Data in RoutingChartDataArr:

      error_data_str_sub_arr = []
      result_sub_arr = []

      msg_id = str(int(Data[0][2:],16))
      msg_source_channel = getChnNum(Data[1])
      msg_dest_channel_arr = []

      for i in range(2,len(Data)):
        msg_dest_channel_arr.append(Data[i])

      result_sub_arr.append(str(index+1))
      result_sub_arr.append(Data[0])

      Curr_result = log_DelayTime_Chk(msg_id,msg_source_channel,msg_dest_channel_arr,frame_routingchn_StrArr[index],error_data_str_sub_arr)

      for curr_err_data in error_data_str_sub_arr:
        error_data_str_arr.append(curr_err_data)
      
      for j in range(len(Curr_result)):
        result_sub_arr.append(Curr_result[j])

      result_arr.append(result_sub_arr)
      index += 1
      print(str(round(index/len(RoutingChartDataArr)*100,2)) + '%')

    print('Start write data in delayTimeChk.xlsx\n')

    FirstRowsArr = ['No.','msg id','SrcChn check','NoRouting check','ErrorRouting check','LossRouting check','DuplicateRouting check','delaytime check','Remark']
    xlsx_workbook = Workbook()
    summary_sheet = xlsx_workbook.active
    summary_sheet.title = 'Summary'

    summary_sheet.column_dimensions['A'].width = 10
    summary_sheet.column_dimensions['B'].width = 10
    summary_sheet.column_dimensions['C'].width = 15
    summary_sheet.column_dimensions['D'].width = 20
    summary_sheet.column_dimensions['E'].width = 20
    summary_sheet.column_dimensions['F'].width = 20
    summary_sheet.column_dimensions['G'].width = 25
    summary_sheet.column_dimensions['H'].width = 20
    summary_sheet.column_dimensions['I'].width = 30

    for i in range(len(FirstRowsArr)):
      summary_sheet.cell(row=1,column=i+1,value=FirstRowsArr[i]).alignment = Alignment(horizontal='center', vertical='center')
      summary_sheet.cell(row=1,column=i+1).border = Border(left=Side(style='thin'),right=Side(style='thin'),top=Side(style='thin'),bottom=Side(style='thin'))
 
    for column in range(1,len(FirstRowsArr)+1):
      summary_sheet.cell(row=1, column=column).fill = PatternFill(start_color='BCD2EE', end_color='BCD2EE', fill_type='solid')

    for i in range(len(result_arr)):
      for j in range(len(result_arr[i])):
        summary_sheet.cell(row=i+2,column=j+1,value=result_arr[i][j]).alignment = Alignment(horizontal='center', vertical='center')
        summary_sheet.cell(row=i+2,column=j+1).border = Border(left=Side(style='thin'),right=Side(style='thin'),top=Side(style='thin'),bottom=Side(style='thin'))
        if result_arr[i][j] == 'Pass':
          summary_sheet.cell(row=i+2, column=j+1).fill = PatternFill(start_color='B7FF4A', end_color='B7FF4A', fill_type='solid')
        elif result_arr[i][j] == 'Failed':
          summary_sheet.cell(row=i+2, column=j+1).fill = PatternFill(start_color='FF5809', end_color='FF5809', fill_type='solid')
        elif result_arr[i][j] == 'NT':
          summary_sheet.cell(row=i+2, column=j+1).fill = PatternFill(start_color='ADADAD', end_color='ADADAD', fill_type='solid')

    if len(error_data_str_arr) != 0:
      error_data_sheet = xlsx_workbook.create_sheet(title='Error Data')

      error_data_sheet.column_dimensions['A'].width = 10
      error_data_sheet.column_dimensions['B'].width = 20
      error_data_sheet.column_dimensions['C'].width = 25
      error_data_sheet.column_dimensions['D'].width = 18
      error_data_sheet.column_dimensions['E'].width = 18
      error_data_sheet.column_dimensions['F'].width = 18
      error_data_sheet.column_dimensions['G'].width = 18
      error_data_sheet.column_dimensions['H'].width = 18
      error_data_sheet.column_dimensions['I'].width = 25
      error_data_sheet.column_dimensions['J'].width = 15
      error_data_sheet.column_dimensions['K'].width = 25

      error_data_sheet_firstRowStr = ['Msg id','Error type','SrcChnTime','SrcChn','ErrorRoutingTime','ErrorRoutingChn','LossRoutingChn','DupRoutingChn','DestTime','DestChn','DelayTime(>0.001s[1ms])']

      for j in range(len(error_data_sheet_firstRowStr)):
        error_data_sheet.cell(row=1,column=j+1,value=error_data_sheet_firstRowStr[j]).alignment = Alignment(horizontal='center', vertical='center')
        error_data_sheet.cell(row=1,column=j+1).border = Border(left=Side(style='thin'),right=Side(style='thin'),top=Side(style='thin'),bottom=Side(style='thin'))

      for column in range(1,len(error_data_sheet_firstRowStr)+1):
        error_data_sheet.cell(row=1, column=column).fill = PatternFill(start_color='BCD2EE', end_color='BCD2EE', fill_type='solid')

      for x in range(len(error_data_str_arr)):
        for y in range(len(error_data_str_arr[x])):
          error_data_sheet.cell(row=x+2,column=y+1,value=error_data_str_arr[x][y]).alignment = Alignment(horizontal='center', vertical='center')
          error_data_sheet.cell(row=x+2,column=y+1).border = Border(left=Side(style='thin'),right=Side(style='thin'),top=Side(style='thin'),bottom=Side(style='thin'))

    xlsx_workbook.save(curr_work_dir + '\\log_analysis_result\\delayTimeChk.xlsx')

def BLFReader_getData():

  global LogData_Arr
  LogData_Arr = []

  curr_log_data = can.BLFReader(blf_file)

  for log_frame in curr_log_data:
    LogData_SubArr = []
    LogData_SubArr.append(log_frame.timestamp)         # [0]:timestamp
    LogData_SubArr.append(log_frame.arbitration_id)    # [1]:id
    LogData_SubArr.append(log_frame.is_rx)             # [2]:direction,Rx:True;Tx:False
    LogData_SubArr.append(log_frame.data[2])           # [3]:Counter byte
    LogData_SubArr.append(log_frame.channel)           # [4]:Channel
    LogData_Arr.append(LogData_SubArr)

def main():

  if len(sys.argv) == 3:

    Mode = sys.argv[1]
    global curr_work_dir
    global dbc_folderPath
    global blf_file

    blf_file = sys.argv[2]
    log_file_format = re.sub('[\u4e00-\u9fa5]','',os.path.basename(blf_file)).split('.')[-1]
    curr_work_dir = os.path.dirname(__file__)
    dbc_folderPath = curr_work_dir + '\\Databases\\'

    if Mode == '-l':

      if log_file_format == 'blf':
        CreateFolder('log_analysis_result')
        getLossMsgData()
        print('********** SUCCESS !!! **********')
      else:
        print('\n******* Prompt : Only supports parsing .blf files !!! *******')

    elif Mode == '-p':

      if log_file_format == 'blf':
        CreateFolder('log_analysis_result')
        BLFReader_getData()
        PacketLoss_check()
        print('********** SUCCESS !!! **********')
      else:
        print('\n******* Prompt : Only supports parsing .blf files !!! *******')

    elif Mode == '-d':

      if log_file_format == 'blf':
        CreateFolder('log_analysis_result')
        BLFReader_getData()
        DelayTime_check()
        print('********** SUCCESS !!! **********')
      else:
        print('\n******* Prompt : Only supports parsing .blf files !!! *******')

    elif Mode == '-v':
      print('\n******* Prompt : No need to pass in the log file !!! *******')
    elif Mode == '-h':
      print('\n******* Prompt : No need to pass in the log file !!! *******')
    else:
      print("\n******* Prompt : parameter error,only '-l','-p','-v','-h' or '-d' is supported !!! *******")

  elif len(sys.argv) == 2:

    Mode = sys.argv[1]

    if Mode == '-v':
      print('\n' + Version)
    elif Mode == '-h':
      print('\n-l     : Obtain BLF file loss message and place the result in the msg_loss.xlsx table')
      print('-p     : Check for packet loss in the BLF file and place the result in the PktLossChk.xlsx table')
      print('-d     : Check the delay time of messages in the BLF file and place the result in the delayTimeChk.xlsx table')
      print('-v     : Output current version number')
      print('-h     : print this help message')
    elif Mode == '-l':
      print('\n******* Prompt : No found .blf file !!! *******')
    elif Mode == '-p':
      print('\n******* Prompt : No found .blf file !!! *******')
    elif Mode == '-d':
      print('\n******* Prompt : No found .blf file !!! *******')
    else:
      print("\n******* Prompt : parameter error,only '-l','-p','-v','-h' or '-d' is supported !!! *******")

  else:
    print('\n******* Wrong way to use, please read the instructions carefully !!! *******')

if __name__ == '__main__':
  main()
