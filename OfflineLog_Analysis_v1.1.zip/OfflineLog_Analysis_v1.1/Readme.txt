工具使用指南

1、解析log前的准备工作

(1)根据log录制时的实际通道配置对应修改ini文件夹下的channel_mapping.ini文件
(2)把从CMX表中捞出的CCU tx Frame table（即CCUSendFrame.ini文件）放至ini文件夹下（CCUSendFrame.ini要与log的项目对应，即生成CCUSendFrame.ini的CMX表要与log项目一致）
(3)把log对应项目的所有dbc文件放至Databases文件夹下
(4)电脑配置了python环境，以及工具解析用到的py库(包括can,openpyxl)，均可通过pip install安装
(5)如果需要使用delaytime解析功能，即-d指令，则需要把从CMX表中捞出的RoutingChart.ini文件放至ini文件夹下

2、指令详解

根据解析需求在cmd窗口运行以下指令(运行指令时，py工具文件和待解析的blf文件要加绝对路径，可以将文件拖入cmd窗口，这样系统会自动将绝对路径带入),目前仅支持以下5种参数
(注意：如需执行前3个参数指令，需在执行指令前关闭之前打开的log_analysis_result文件夹下的对应表格，否则会写入数据失败报错，切记！！！)

(1)python OfflineLogAnalysis.py -l xxx.blf

此指令是以\ini\CCUSendFrame.ini为标准，解析xxx.blf文件中是否存在上述ini文件列出的message，解析结果会放至log_analysis_result文件夹下的msg_loss.xlsx表格中（文件列出的是未包含的信号以及数量）

(2)python OfflineLogAnalysis.py -p xxx.blf

此指令是以\ini\CCUSendFrame.ini为标准，解析xxx.blf文件数据是否存在上述ini文件列出的message发送过程中丢包的现象，解析结果会放到log_analysis_result文件夹下的PktLossChk.xlsx表格中

(3)python OfflineLogAnalysis.py -d xxx.blf

此指令解析Rouitng信号（CMX-->GWRoutingChart-->LLCE=1且type不属于POE、PA、Event的那些）从Source channel路由到每个Destination channel的delaytime，check:①delaytime<=1ms[0.001s];②Source channel is correct;③The routing channel is correct,No error routing/lost routing/duplicate routing.解析结果会放到log_analysis_result文件夹下的delayTimeChk.xlsx表格中

(4)python OfflineLogAnalysis.py -v

打印当前OfflineLogAnalysis.py文件的版本号

(5)python OfflineLogAnalysis.py -h

打印当前工具支持的指令参数(即上述5种)及其对应的含义

