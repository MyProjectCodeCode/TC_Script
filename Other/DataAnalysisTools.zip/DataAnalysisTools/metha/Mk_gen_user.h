/* This file is generated automatically. DO NOT EDIT!!
 *
 * EB tresos AutoCore OS 6.1.138 CORTEXM/S32G399
 * (Build 20230216)
 *
 * (c) 1998-2023 Elektrobit Automotive GmbH
 * Am Wolfsmantel 46
 * 91058 Erlangen
 * GERMANY
 *
 * Date         : 5/10/23 2:31 PM           !!!IGNORE-LINE!!!
 */

#ifndef MK_GEN_USER_H
#define MK_GEN_USER_H
#ifdef __cplusplus
extern "C" {
#endif

/*
 * MISRA-C:2012 Deviation List
 *
 * MISRAC2012-1) Deviated Rule: 20.1 (advisory)
 * #include statements in a file should only be preceded by
 * preprocessor directives or comments.
 *
 * Reason:
 * The C++ guards allow usage of the OS with a C++-compiler.
 */

/* Deviation MISRAC2012-1 <*> */

#include <public/Mk_autosar.h>

/*===================================================================
 * Addons
 *==================================================================*/

/*===================================================================
 * Applications
 *==================================================================*/
#define OsApplication_C0  0
#define OsApplication_C1  1
#define OsApplication_C2  2
#define OS_SYSTEM_0  3
#define OS_SYSTEM_1  4
#define OS_SYSTEM_2  5


/*===================================================================
 * Events
 *==================================================================*/
#define SchM_OSShutdownEvent  0x0001u
#define Rte_OSTriggerExecutableEvent_OsTask_FG1_BswEvent_C0_DRE_ADF47154EE61C2632706B3D1924B9613  0x0002u
#define Rte_OSTriggerExecutableEvent_OsTask_FG1_BswEvent_C0_DRE_DB9862639643741999DE290A52B731E4  0x0004u
#define Rte_OSTriggerExecutableEvent_OsTask_FG1_BswEvent_C0_IRTRIGGER_2DE8BF7D9401C07597075D34F029F23C  0x0008u
#define Rte_OSTriggerExecutableEvent_OsTask_FG1_BswEvent_C0_IRTRIGGER_532F34AF675F31DACC18B59ACC68EFE3  0x0010u
#define Rte_OSTriggerExecutableEvent_OsTask_FG1_BswEvent_C0_IRTRIGGER_17BB4C87CA60A9485E768FADA2E7EC20  0x0020u
#define Rte_OSShutdownEvent  0x0001u
#define Rte_OSTriggerExecutableEvent  0x0002u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_ModeSwitchEvent_C0_MSE_D7F15A76B1FB31DC30BF8913DB428EC0  0x0002u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_ModeSwitchEvent_C0_MSE_087E0FB189825147B7735BE76B4B254E  0x0004u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_ModeSwitchEvent_C0_MSE_42ABF424081CA72844CC3FF5BB738474  0x0008u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_B12D9106239DAEECE6941AAF5D888E9F  0x0004u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_ModeSwitchEvent_C1_MSE_82DEC4EEC25BF471CB4EBFE588F0376C  0x0002u
#define Rte_OSResolveWaitPointEvent  0x0004u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_ModeSwitchEvent_C2_MSE_1882A322616C18BF14869F9F24110393  0x0002u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C0_DRE_640E560FDCA54365D014BA1A4604D97E  0x0004u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C0_DRE_17D891FE92FEFEC2A73DD28C966407F9  0x0008u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C0_DRE_631BE501C65D70D472E382067F2820F3  0x0010u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C0_DRE_206974980A8A6B3D37B452CC9E5F0E25  0x0020u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C0_DRE_400B3EA5474EB1005DE070ECC25B95BE  0x0040u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C0_DRE_8E223566CEE242908E7EE0EBE870C064  0x0080u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_85CB6D6B67DECD26779F139536AE9749  0x0008u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_B4BA517D54238EFFEBDDA490E4CC3262  0x0010u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_09A917423C2C278625160AEAE9B77F40  0x0020u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_70ECE55A626C830D68E26468A817369D  0x0040u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_553C07D03D9C5001B67EDE1ECEC632FD  0x0080u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_6FEB19EBCC70EF4DF62DE3E5CCBA5194  0x0100u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_E5AA392264691CE01870EFAD4D768317  0x0200u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_E2A651EF346349A0E69C23D0C478D683  0x0400u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_FC464CF43DC902EA746F71B00DCE776D  0x0800u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_86F12DE6A750F49A7FA9BAE84ED5C2C7  0x01000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_0E9160E488DC6692DD4F3E7224BA97AA  0x02000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_BEB75ACB25B6215F0F099DB7640A1797  0x04000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_B4DA3CEE82C22C9007309F059AD41EA0  0x08000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_BDA1603BAA2085A6127778DAAC93DDEF  0x10000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_307DFEBA36EFB7C701CA87A6C70F8DC6  0x20000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_55F543CDEC90FF697688BDFA19EE3B7C  0x40000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_2BDAE2D83F3E263F9A7381F36BFA0F52  0x80000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_76AC02ACE8528CC4E4579D6287207172  0x100000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_40EEE18CAEE1FB0023B5952A2D1F7CC6  0x200000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_20B5FBDEBEAAFA8FDD2559426A620C3E  0x400000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_FBAE1C47897612331940BCDB3E3110A2  0x800000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_44E4866BE785E412CCD87934428E50DC  0x1000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_8B1C15316587D5FD8FCAE8916D709612  0x2000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_C5BAA29A54B75A1C343F2E15C4675084  0x4000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_E8077BA87474BF1E5BB059A9485564C1  0x8000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_0C883964DBD38FE6C3821F2788514390  0x10000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_4CEA2F51E3540A0457E9F6B11AB64672  0x20000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_A9094F8BABD0CD2C7C89976E2339967D  0x0002u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_7626412173204B1422751DF0BE110A7F  0x0004u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_999F28ADE22E3D860AC7971FDFA24041  0x0008u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_563EF66F29C880456E19C3CBEAC1CC04  0x0010u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_6622D11E98D0AFDA22324A85F5339815  0x0020u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_3586FD898377D725E59CCBDE144FF938  0x0040u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_25C51C727F867489E1C20123C09D25E5  0x0080u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_AB37B71CB7FDA2C8B297432C87AF5296  0x0100u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_9C159F673666578E43CDDA7E6DF0450A  0x0200u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_97E459F32684148A5AEA6AE2B5B462F1  0x0400u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_A89C33BAFD3825EAB597F74C020E9EF0  0x0800u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_6E4B7ABD00FFAC5C09D49D73D399F20B  0x01000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_195BE7DBD26C87A6F6A7735C9D8A23BB  0x02000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_6E82C77512BEB2B82AA26B73634B031D  0x04000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_5F844147A5D565668BDDA28F943F6B23  0x08000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_52EB966845E22C2D0A26A73E689607EA  0x10000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_9918669D84D21B5DC6C2D33448BC9783  0x20000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_0C1642DF7B96B22F7D5E93B61D84ACB2  0x40000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_AA0A6AD05EF6EDDC4BCFD3A12AA62738  0x80000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_880C6C3B855B37681A3136A58DC058C7  0x100000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_54D42A9D272A99F96D0142C6070C15D9  0x200000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_5DE6B0F14541DD78A69434F3DB3C3A95  0x400000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_426EE8616A122D789FA66E609D799C54  0x800000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_131D24F80C1040A2769471F46E34E0DF  0x1000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_D_DRE_AEE9EC692E2A19247E6834B5242D92DA  0x2000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_78B838C6C1CD3265E38544705A3CA33B  0x0002u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_9E8D68E73C2DE48475821C28F71E229C  0x0004u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_352E62B7C5C89B5E74919FC35CEA4BFA  0x0008u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_A1BEB0127CBF5AE265C81B437408E939  0x0010u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_D96D47F31B946136116DE7819EEFA1D2  0x0020u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_85B6AFCE9B7EC312F27ACAACD8652DD5  0x0040u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_CDCB0A86E0D9F95372397736BC0B7FB8  0x0080u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_418C23841DE727780A16B4A3418CA16A  0x0100u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_93845861CA5342AB9C0860472753226D  0x0200u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_0140566BD9B0EA88A65394E7AE35B324  0x0400u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_12E5A70D51EEE43B1CFDAC5A07E20BAC  0x0800u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_88B01D86D99FD23472F712DD470858F1  0x01000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_AF9B33C9C327DC825FB14C95406F9D65  0x02000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_C71E65D1BA7D628EC3474343BD36459D  0x04000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_76B4A089DD6CB9299F09C2D7697B4D66  0x08000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_0E6F2284651E86F0A1F8C3756AD14EC6  0x10000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_59406B5AC2C66153BD553BC3303C412E  0x20000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_1E16739B45F6431685167F65FB860546  0x40000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_79908F9649DCA8B84F9A64DE7656BDCC  0x80000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_6BCE68D43842F19D27661A61F58A2449  0x100000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_50384684C23C174CFFB88D377188A7CE  0x200000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_C5BA34E76E09131910CA9740490B60B0  0x400000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_4DF52CD722A4FDFBDDBB495EA08E62FE  0x800000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_EB1B0ACAB5F8091F1E2BA7DF6B7DBAB1  0x1000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_CDFC45D00B402CDE7018C583675F92AB  0x2000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_42F1B6E6D44F4045B67A6E66E8E1C2DB  0x4000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_E9E7831824DCFEF7C647A18DA56920AA  0x0002u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_16EC4634AD10DE15B4244D36BC205EA2  0x0004u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_53DB9D701C1E67D1B09B27B0EE70B6DD  0x0008u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_7F74A2F243C39D4FFDA37E2DEA48A5DD  0x0010u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_A06B1CA539F683DFC8AB3E0544CBDE61  0x0020u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_C970DBD416C2B34AE6E2CF3BDA8FA774  0x0040u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_02E9E2E783675B55C52BE8C2F0B79D77  0x0080u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_BA1329C8B189064B0D7DB6A300860B26  0x0100u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_09ACAC33909C922017043FC006CCC908  0x0200u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_AF936153147F58FD30964256E49426FD  0x0400u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_D0695068656E7CB0D24D45FD2CBCABFD  0x0800u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_303DE29D4068C1707FC46B37D8A41311  0x01000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_4EAC3E1F2B5E9D51C24046D7F686DDF1  0x02000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_F365705D717B18E62D78E6FC25D70AA2  0x04000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_987A37C78EEA742E855ADBF46C8D04E6  0x08000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_2742078172088B34FF12353707816756  0x10000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_05D489866CA7CBDE27299F3258C3A607  0x20000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_2CA9B0ECED88138C7BB5040B15B8AB6B  0x40000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_251A0DBAFE065BFBAAF5D4B97E31A202  0x80000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_72CF36B6BDFD7E5DA71F388E96F9E1EB  0x100000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_5B2FE4325D643926E313ADC092137924  0x200000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_68A4A6D4EE873D472FAE62C5DB844B01  0x400000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_3DE5AF75CA7E0E5F584B4B6BE864E0B4  0x800000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_218A9D6C3FDAB322AE702127D0B500AA  0x1000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_7B82F36EB063A5B437765A3115552353  0x2000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_9AB3BE7DF8DEA81378CEB92B80E27740  0x4000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_10BF1F1EA2C2B0839B766820BA40ACC0  0x8000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_8D88A4D598B1FA2CE245803338055779  0x10000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_735A221AD4F47D205465B2CC6D5581F0  0x0002u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_6D5D43EE684F59B76E6248F0ED408F54  0x0004u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_A88F53AC97435CB47FC2DA94C4435B74  0x0008u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_4D9024668AFBF663E034A03B9453BCFC  0x0010u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_8EE19A925CCF8DDAC92CE870900C8275  0x0020u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_157B471B9F6C76D9E13CD43FC765A6A5  0x0040u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_8CF74FCA342CF201FC08D7E9E91DD14A  0x0080u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_7DBB78FF415E579B612D94348A769A58  0x0100u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_96765686364E512BDA01ED64B5EB29D3  0x0200u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_6646A1BAE87417FA8972000314A58A59  0x0400u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_25A487C0A3EF8D7B53FEB3F0414A6783  0x0800u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_7664A08AB69D3A4F59A7681CDABE0FCA  0x01000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_E7D152E0EB32B827C2D8A2DDCE4E9AB6  0x02000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_335D6AFADC24D9FAED738DBCE7B136B7  0x04000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_325C97479B6A12939854B34D28A77AF7  0x08000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_A46B1CED484B6E032715CA82EA0A007D  0x10000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_F003EEE2780C57B8939EC33A96B050AD  0x20000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_A5C6E8D738390834E52A2ADB4E42733E  0x40000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_75F21341F1A6B5861A8161D556E8D4C4  0x80000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_9C2BBA05DDB043F655D009016654A364  0x100000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_5642A5065EDCF3E629B5E78158298BC3  0x200000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_5FAC4DF08D4BA93B6BB3373A1D4FBE4C  0x400000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_C5827858CC223BEDD63BCEA5860E9BA7  0x800000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_CAFA46C296833EF9BA24CBF854889DCB  0x1000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_0374D4A20FBB52331FB0B7E1AA10B287  0x2000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_BA4B4DEB7A34614B8B7030B16939B61D  0x4000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_5C2E171FFBC9987F0B5D5DA552703D0D  0x8000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_388563D1B8289D7A27E83A89AA772EE6  0x10000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_C_DRE_BAF428188204777AC4F57521FD7C622E  0x20000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_DRE_41BAA07CE6A6BF20ED383725B98BA80F  0x40000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_33E319216A2984587C26D7CF9AE37F14  0x8000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_652007277121F80DCE10D13436DB958E  0x10000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_A_DRE_CE23A4D6E260F212D83AD4370B509A1F  0x20000000u
#define Rte_OSTriggerExecutableEvent_RteTask_FG1_DataReceivedEvent_C1_B_DRE_5E47FFEA65029A5D6DA24787683D1AC7  0x20000000u

/*===================================================================
 * Interrupts
 *==================================================================*/
#ifndef MK_ASM
#define Adc_Sar_0_Isr  0
#define Adc_Sar_1_Isr  1
#define Can_FifoRxInNotEmptyIsr_0_7  2
#define Can_FifoRxOutNotEmptyIsr_0_7  3
#define Can_FifoTxAckNotEmptyIsr_0_7  4
#define Eth_43_PFE_BmuIrqHdlr  5
#define Eth_43_PFE_HifIrqHdlr_0  6
#define Eth_RxIrqHdlr_0  7
#define Eth_TxIrqHdlr_0  8
#define FTM_0_ISR  9
#define PIT_0_ISR  10
#define STM_6_ISR  11
#define RTC_0_Ch_0_ISR  12
#define Tmu_Isr  13
#define WKPU_EXT_IRQ_SINGLE_ISR  14
#define OsIsr_MSCM_INT2_IRQn  15
#define OsIsr_MSCM_INT4_IRQn  16
#define FCCU_ALARM_ISR  17
#define FCCU_TIMEOUT_ISR  18
#define STCU_ISR  19
#define OsIsr_I229_XRDC_0  20
#define OsIsr_I230_XRDC_1  21
#define SIUL2_1_ICU_EIRQ_SINGLE_INT_HANDLER  22
#define Os_Counter_STM0_0  23
#define Os_Counter_STM1_0  24
#define Os_Counter_STM2_0  25
extern void OS_ISR_Adc_Sar_0_Isr(void);
extern void OS_ISR_Adc_Sar_1_Isr(void);
extern void OS_ISR_Can_FifoRxInNotEmptyIsr_0_7(void);
extern void OS_ISR_Can_FifoRxOutNotEmptyIsr_0_7(void);
extern void OS_ISR_Can_FifoTxAckNotEmptyIsr_0_7(void);
extern void OS_ISR_Eth_43_PFE_BmuIrqHdlr(void);
extern void OS_ISR_Eth_43_PFE_HifIrqHdlr_0(void);
extern void OS_ISR_Eth_RxIrqHdlr_0(void);
extern void OS_ISR_Eth_TxIrqHdlr_0(void);
extern void OS_ISR_FTM_0_ISR(void);
extern void OS_ISR_PIT_0_ISR(void);
extern void OS_ISR_STM_6_ISR(void);
extern void OS_ISR_RTC_0_Ch_0_ISR(void);
extern void OS_ISR_Tmu_Isr(void);
extern void OS_ISR_WKPU_EXT_IRQ_SINGLE_ISR(void);
extern void OS_ISR_OsIsr_MSCM_INT2_IRQn(void);
extern void OS_ISR_OsIsr_MSCM_INT4_IRQn(void);
extern void OS_ISR_FCCU_ALARM_ISR(void);
extern void OS_ISR_FCCU_TIMEOUT_ISR(void);
extern void OS_ISR_STCU_ISR(void);
extern void OS_ISR_OsIsr_I229_XRDC_0(void);
extern void OS_ISR_OsIsr_I230_XRDC_1(void);
extern void OS_ISR_SIUL2_1_ICU_EIRQ_SINGLE_INT_HANDLER(void);
extern void OS_CounterIsr_HwCounter_C0(void);
extern void OS_CounterIsr_HwCounter_C1(void);
extern void OS_CounterIsr_HwCounter_C2(void);
#endif  /* MK_ASM */

/*===================================================================
 * Resources
 *==================================================================*/
#define RES_SCHEDULER  MK_MakeLockId(0u, 0u)
#define MK_RESCAT1  MK_MakeLockId(0u, 1u)
#define MK_RESCAT2  MK_MakeLockId(0u, 2u)
#define Rte_Spinlock_0  MK_MakeLockId(0u, 3u)
#define Rte_Spinlock_1  MK_MakeLockId(0u, 4u)
#define Rte_Spinlock_2  MK_MakeLockId(0u, 5u)
#define Rte_Spinlock_3  MK_MakeLockId(0u, 6u)
#define Rte_Spinlock_4  MK_MakeLockId(0u, 7u)
#define Rte_Spinlock_5  MK_MakeLockId(0u, 8u)
#define Rte_Spinlock_6  MK_MakeLockId(0u, 9u)
#define Rte_Spinlock_7  MK_MakeLockId(0u, 10u)
#define Rte_Spinlock_8  MK_MakeLockId(0u, 11u)
#define Rte_Spinlock_9  MK_MakeLockId(0u, 12u)
#define Rte_Spinlock_10  MK_MakeLockId(0u, 13u)
#define Rte_Spinlock_11  MK_MakeLockId(0u, 14u)
#define Rte_Spinlock_12  MK_MakeLockId(0u, 15u)
#define Rte_Spinlock_13  MK_MakeLockId(0u, 16u)
#define Rte_Spinlock_14  MK_MakeLockId(0u, 17u)
#define Rte_Spinlock_15  MK_MakeLockId(0u, 18u)
#define Rte_Spinlock_16  MK_MakeLockId(0u, 19u)
#define Rte_Spinlock_17  MK_MakeLockId(0u, 20u)
#define Rte_Spinlock_18  MK_MakeLockId(0u, 21u)
#define Rte_Spinlock_19  MK_MakeLockId(0u, 22u)
#define Rte_Spinlock_20  MK_MakeLockId(0u, 23u)
#define Rte_Spinlock_21  MK_MakeLockId(0u, 24u)
#define Rte_Spinlock_22  MK_MakeLockId(0u, 25u)
#define Rte_Spinlock_23  MK_MakeLockId(0u, 26u)
#define Rte_Spinlock_24  MK_MakeLockId(0u, 27u)
#define Rte_Spinlock_25  MK_MakeLockId(0u, 28u)
#define Rte_Spinlock_26  MK_MakeLockId(0u, 29u)
#define Rte_Spinlock_27  MK_MakeLockId(0u, 30u)
#define Rte_Spinlock_28  MK_MakeLockId(0u, 31u)
#define Rte_Spinlock_29  MK_MakeLockId(0u, 32u)
#define Rte_Spinlock_30  MK_MakeLockId(0u, 33u)
#define Rte_Spinlock_31  MK_MakeLockId(0u, 34u)
#define Rte_Spinlock_32  MK_MakeLockId(0u, 35u)
#define Rte_Spinlock_33  MK_MakeLockId(0u, 36u)
#define Rte_Spinlock_34  MK_MakeLockId(0u, 37u)
#define Rte_Spinlock_35  MK_MakeLockId(0u, 38u)
#define Rte_Spinlock_36  MK_MakeLockId(0u, 39u)
#define Rte_Spinlock_37  MK_MakeLockId(0u, 40u)
#define Rte_Spinlock_38  MK_MakeLockId(0u, 41u)
#define Rte_Spinlock_39  MK_MakeLockId(0u, 42u)
#define Rte_Spinlock_40  MK_MakeLockId(0u, 43u)
#define Rte_Spinlock_41  MK_MakeLockId(0u, 44u)
#define Rte_Spinlock_42  MK_MakeLockId(0u, 45u)
#define Rte_Spinlock_43  MK_MakeLockId(0u, 46u)
#define Rte_Spinlock_44  MK_MakeLockId(0u, 47u)
#define Rte_Spinlock_45  MK_MakeLockId(0u, 48u)
#define Rte_Spinlock_46  MK_MakeLockId(0u, 49u)
#define Rte_Spinlock_47  MK_MakeLockId(0u, 50u)
#define Rte_Spinlock_48  MK_MakeLockId(0u, 51u)
#define Rte_Spinlock_49  MK_MakeLockId(0u, 52u)
#define Rte_Spinlock_50  MK_MakeLockId(0u, 53u)
#define Rte_Spinlock_51  MK_MakeLockId(0u, 54u)
#define Rte_Spinlock_52  MK_MakeLockId(0u, 55u)
#define Rte_Spinlock_53  MK_MakeLockId(0u, 56u)
#define Rte_Spinlock_54  MK_MakeLockId(0u, 57u)
#define Rte_Spinlock_55  MK_MakeLockId(0u, 58u)
#define Rte_Spinlock_56  MK_MakeLockId(0u, 59u)
#define Rte_Spinlock_57  MK_MakeLockId(0u, 60u)
#define Rte_Spinlock_58  MK_MakeLockId(0u, 61u)
#define Rte_Spinlock_59  MK_MakeLockId(0u, 62u)
#define Rte_Spinlock_60  MK_MakeLockId(0u, 63u)
#define Rte_Spinlock_61  MK_MakeLockId(0u, 64u)
#define Rte_Spinlock_62  MK_MakeLockId(0u, 65u)
#define Rte_Spinlock_63  MK_MakeLockId(0u, 66u)
#define Rte_Spinlock_64  MK_MakeLockId(0u, 67u)
#define Rte_Spinlock_65  MK_MakeLockId(0u, 68u)
#define Rte_Spinlock_66  MK_MakeLockId(0u, 69u)
#define Rte_Spinlock_67  MK_MakeLockId(0u, 70u)
#define Rte_Spinlock_68  MK_MakeLockId(0u, 71u)
#define Rte_Spinlock_69  MK_MakeLockId(0u, 72u)
#define Rte_Spinlock_70  MK_MakeLockId(0u, 73u)
#define Rte_Spinlock_71  MK_MakeLockId(0u, 74u)
#define Rte_Spinlock_72  MK_MakeLockId(0u, 75u)
#define Rte_Spinlock_73  MK_MakeLockId(0u, 76u)
#define Rte_Spinlock_74  MK_MakeLockId(0u, 77u)
#define Rte_Spinlock_75  MK_MakeLockId(0u, 78u)
#define Rte_Spinlock_76  MK_MakeLockId(0u, 79u)
#define Rte_Spinlock_77  MK_MakeLockId(0u, 80u)
#define Rte_Spinlock_78  MK_MakeLockId(0u, 81u)
#define Rte_Spinlock_79  MK_MakeLockId(0u, 82u)
#define Rte_Spinlock_80  MK_MakeLockId(0u, 83u)
#define Rte_Spinlock_81  MK_MakeLockId(0u, 84u)
#define Rte_Spinlock_82  MK_MakeLockId(0u, 85u)
#define Rte_Spinlock_83  MK_MakeLockId(0u, 86u)
#define Rte_Spinlock_84  MK_MakeLockId(0u, 87u)
#define Rte_Spinlock_85  MK_MakeLockId(0u, 88u)
#define Rte_Spinlock_86  MK_MakeLockId(0u, 89u)
#define Rte_Spinlock_87  MK_MakeLockId(0u, 90u)
#define Rte_Spinlock_88  MK_MakeLockId(0u, 91u)
#define Rte_Spinlock_89  MK_MakeLockId(0u, 92u)
#define Rte_Spinlock_90  MK_MakeLockId(0u, 93u)
#define Rte_Spinlock_91  MK_MakeLockId(0u, 94u)
#define Rte_Spinlock_92  MK_MakeLockId(0u, 95u)
#define Rte_Spinlock_93  MK_MakeLockId(0u, 96u)
#define Rte_Spinlock_94  MK_MakeLockId(0u, 97u)
#define Rte_Spinlock_95  MK_MakeLockId(0u, 98u)
#define Rte_Spinlock_96  MK_MakeLockId(0u, 99u)
#define Rte_Spinlock_97  MK_MakeLockId(0u, 100u)
#define Rte_Spinlock_98  MK_MakeLockId(0u, 101u)
#define Rte_Spinlock_99  MK_MakeLockId(0u, 102u)
#define Rte_Spinlock_100  MK_MakeLockId(0u, 103u)
#define Rte_Spinlock_101  MK_MakeLockId(0u, 104u)
#define Rte_Spinlock_102  MK_MakeLockId(0u, 105u)
#define Rte_Spinlock_103  MK_MakeLockId(0u, 106u)
#define Rte_Spinlock_104  MK_MakeLockId(0u, 107u)
#define Rte_Spinlock_105  MK_MakeLockId(0u, 108u)
#define Rte_Spinlock_106  MK_MakeLockId(0u, 109u)
#define Rte_Spinlock_107  MK_MakeLockId(0u, 110u)
#define Rte_Spinlock_108  MK_MakeLockId(0u, 111u)
#define Rte_Spinlock_109  MK_MakeLockId(0u, 112u)
#define Rte_Spinlock_110  MK_MakeLockId(0u, 113u)
#define Rte_Spinlock_111  MK_MakeLockId(0u, 114u)
#define Rte_Spinlock_112  MK_MakeLockId(0u, 115u)
#define Rte_Spinlock_113  MK_MakeLockId(0u, 116u)
#define Rte_Spinlock_114  MK_MakeLockId(0u, 117u)
#define Rte_Spinlock_115  MK_MakeLockId(0u, 118u)
#define Rte_Spinlock_116  MK_MakeLockId(0u, 119u)
#define Rte_Spinlock_117  MK_MakeLockId(0u, 120u)
#define Rte_Spinlock_118  MK_MakeLockId(0u, 121u)
#define Rte_Spinlock_119  MK_MakeLockId(0u, 122u)
#define Rte_Spinlock_120  MK_MakeLockId(0u, 123u)
#define Rte_Spinlock_121  MK_MakeLockId(0u, 124u)
#define Rte_Spinlock_122  MK_MakeLockId(0u, 125u)
#define Rte_Spinlock_123  MK_MakeLockId(0u, 126u)
#define Rte_Spinlock_124  MK_MakeLockId(0u, 127u)
#define Rte_Spinlock_125  MK_MakeLockId(0u, 128u)
#define Rte_Spinlock_126  MK_MakeLockId(0u, 129u)
#define Rte_Spinlock_127  MK_MakeLockId(0u, 130u)
#define Rte_Spinlock_128  MK_MakeLockId(0u, 131u)
#define Rte_Spinlock_129  MK_MakeLockId(0u, 132u)
#define Rte_Spinlock_130  MK_MakeLockId(0u, 133u)
#define Rte_Spinlock_131  MK_MakeLockId(0u, 134u)
#define Rte_Spinlock_132  MK_MakeLockId(0u, 135u)
#define Rte_Spinlock_133  MK_MakeLockId(0u, 136u)
#define Rte_Spinlock_134  MK_MakeLockId(0u, 137u)
#define Rte_Spinlock_135  MK_MakeLockId(0u, 138u)
#define Rte_Spinlock_136  MK_MakeLockId(0u, 139u)
#define Rte_Spinlock_137  MK_MakeLockId(0u, 140u)
#define Rte_Spinlock_138  MK_MakeLockId(0u, 141u)
#define Rte_Spinlock_139  MK_MakeLockId(0u, 142u)
#define Rte_Spinlock_140  MK_MakeLockId(0u, 143u)
#define Rte_Spinlock_141  MK_MakeLockId(0u, 144u)
#define Rte_Spinlock_142  MK_MakeLockId(0u, 145u)
#define Rte_Spinlock_143  MK_MakeLockId(0u, 146u)
#define Rte_Spinlock_144  MK_MakeLockId(0u, 147u)
#define Rte_Spinlock_145  MK_MakeLockId(0u, 148u)
#define Rte_Spinlock_146  MK_MakeLockId(0u, 149u)
#define Rte_Spinlock_147  MK_MakeLockId(0u, 150u)
#define Rte_Spinlock_148  MK_MakeLockId(0u, 151u)
#define Rte_Spinlock_149  MK_MakeLockId(0u, 152u)
#define Rte_Spinlock_150  MK_MakeLockId(0u, 153u)
#define Rte_Spinlock_151  MK_MakeLockId(0u, 154u)
#define Rte_Spinlock_152  MK_MakeLockId(0u, 155u)
#define Rte_Spinlock_153  MK_MakeLockId(0u, 156u)
#define Rte_Spinlock_154  MK_MakeLockId(0u, 157u)
#define Rte_Spinlock_155  MK_MakeLockId(0u, 158u)
#define Rte_Spinlock_156  MK_MakeLockId(0u, 159u)
#define Rte_Spinlock_157  MK_MakeLockId(0u, 160u)
#define Rte_Spinlock_158  MK_MakeLockId(0u, 161u)
#define Rte_Spinlock_159  MK_MakeLockId(0u, 162u)
#define Rte_Spinlock_160  MK_MakeLockId(0u, 163u)
#define Rte_Spinlock_161  MK_MakeLockId(0u, 164u)
#define Rte_Spinlock_162  MK_MakeLockId(0u, 165u)
#define Rte_Spinlock_163  MK_MakeLockId(0u, 166u)
#define Rte_Spinlock_164  MK_MakeLockId(0u, 167u)
#define Rte_Spinlock_165  MK_MakeLockId(0u, 168u)
#define Rte_Spinlock_166  MK_MakeLockId(0u, 169u)
#define Rte_Spinlock_167  MK_MakeLockId(0u, 170u)
#define Rte_Spinlock_168  MK_MakeLockId(0u, 171u)
#define Rte_Spinlock_169  MK_MakeLockId(0u, 172u)
#define Rte_Spinlock_170  MK_MakeLockId(0u, 173u)
#define Rte_Spinlock_171  MK_MakeLockId(0u, 174u)
#define Rte_Spinlock_172  MK_MakeLockId(0u, 175u)
#define Rte_Spinlock_173  MK_MakeLockId(0u, 176u)
#define Rte_Spinlock_174  MK_MakeLockId(0u, 177u)
#define Rte_Spinlock_175  MK_MakeLockId(0u, 178u)
#define Rte_Spinlock_176  MK_MakeLockId(0u, 179u)
#define Rte_Spinlock_177  MK_MakeLockId(0u, 180u)
#define Rte_Spinlock_178  MK_MakeLockId(0u, 181u)
#define Rte_Spinlock_179  MK_MakeLockId(0u, 182u)
#define Rte_Spinlock_180  MK_MakeLockId(0u, 183u)
#define Rte_Spinlock_181  MK_MakeLockId(0u, 184u)
#define Rte_Spinlock_182  MK_MakeLockId(0u, 185u)
#define Rte_Spinlock_183  MK_MakeLockId(0u, 186u)
#define Rte_Spinlock_184  MK_MakeLockId(0u, 187u)
#define Rte_Spinlock_185  MK_MakeLockId(0u, 188u)
#define Rte_Spinlock_186  MK_MakeLockId(0u, 189u)
#define Rte_Spinlock_187  MK_MakeLockId(0u, 190u)
#define Rte_Spinlock_188  MK_MakeLockId(0u, 191u)
#define Rte_Spinlock_189  MK_MakeLockId(0u, 192u)
#define Rte_Spinlock_190  MK_MakeLockId(0u, 193u)
#define Rte_Spinlock_191  MK_MakeLockId(0u, 194u)
#define Rte_Spinlock_192  MK_MakeLockId(0u, 195u)
#define Rte_Spinlock_193  MK_MakeLockId(0u, 196u)
#define Rte_Spinlock_194  MK_MakeLockId(0u, 197u)
#define Rte_Spinlock_195  MK_MakeLockId(0u, 198u)
#define Rte_Spinlock_196  MK_MakeLockId(0u, 199u)
#define Rte_Spinlock_197  MK_MakeLockId(0u, 200u)
#define Rte_Spinlock_198  MK_MakeLockId(0u, 201u)
#define Rte_Spinlock_199  MK_MakeLockId(0u, 202u)
#define Rte_Spinlock_200  MK_MakeLockId(0u, 203u)
#define Rte_Spinlock_201  MK_MakeLockId(0u, 204u)
#define Rte_Spinlock_202  MK_MakeLockId(0u, 205u)
#define Rte_Spinlock_203  MK_MakeLockId(0u, 206u)
#define Rte_Spinlock_204  MK_MakeLockId(0u, 207u)
#define Rte_Spinlock_205  MK_MakeLockId(0u, 208u)
#define Rte_Spinlock_206  MK_MakeLockId(0u, 209u)
#define Rte_Spinlock_207  MK_MakeLockId(0u, 210u)
#define Rte_Spinlock_208  MK_MakeLockId(0u, 211u)
#define Rte_Spinlock_209  MK_MakeLockId(0u, 212u)
#define Rte_Spinlock_210  MK_MakeLockId(0u, 213u)
#define Rte_Spinlock_211  MK_MakeLockId(0u, 214u)
#define Rte_Spinlock_212  MK_MakeLockId(0u, 215u)
#define Rte_Spinlock_213  MK_MakeLockId(0u, 216u)
#define Rte_Spinlock_214  MK_MakeLockId(0u, 217u)
#define Rte_Spinlock_215  MK_MakeLockId(0u, 218u)
#define Rte_Spinlock_216  MK_MakeLockId(0u, 219u)
#define Rte_Spinlock_217  MK_MakeLockId(0u, 220u)
#define Rte_Spinlock_218  MK_MakeLockId(0u, 221u)
#define Rte_Spinlock_219  MK_MakeLockId(0u, 222u)
#define Rte_Spinlock_220  MK_MakeLockId(0u, 223u)
#define Rte_Spinlock_221  MK_MakeLockId(0u, 224u)
#define Rte_Spinlock_222  MK_MakeLockId(0u, 225u)
#define Rte_Spinlock_223  MK_MakeLockId(0u, 226u)
#define Rte_Spinlock_224  MK_MakeLockId(0u, 227u)

/*===================================================================
 * Simple Schedule Tables
 *==================================================================*/

/*===================================================================
 * Tasks
 *==================================================================*/
#ifndef MK_ASM
extern void OS_TASK_OsTask_FG1_BswEvent_C0(void);
extern void OS_TASK_RteTask_FG1_DataReceivedEvent_C0(void);
extern void OS_TASK_RteTask_FG1_DataReceivedEvent_C1(void);
extern void OS_TASK_RteTask_FG1_ModeSwitchEvent_C0(void);
extern void OS_TASK_RteTask_FG1_ModeSwitchEvent_C1(void);
extern void OS_TASK_RteTask_FG1_ModeSwitchEvent_C2(void);
extern void OS_TASK_RteTask_FG1_DataReceivedEvent_C1_A(void);
extern void OS_TASK_RteTask_FG1_DataReceivedEvent_C1_B(void);
extern void OS_TASK_RteTask_FG1_DataReceivedEvent_C1_C(void);
extern void OS_TASK_RteTask_FG1_DataReceivedEvent_C1_D(void);
extern void OS_TASK_Idle_Task_C0(void);
extern void OS_TASK_Idle_Task_C1(void);
extern void OS_TASK_Idle_Task_C2(void);
extern void OS_TASK_Init_Task_C0(void);
extern void OS_TASK_Init_Task_C1(void);
extern void OS_TASK_Init_Task_C2(void);
extern void OS_TASK_OsTask_FG1_1000ms_C0(void);
extern void OS_TASK_OsTask_FG1_100ms_C0(void);
extern void OS_TASK_OsTask_FG1_10ms_C0_A(void);
extern void OS_TASK_OsTask_FG1_10ms_C0_B(void);
extern void OS_TASK_OsTask_FG1_10ms_CAN_C0(void);
extern void OS_TASK_OsTask_FG1_20ms_C0(void);
extern void OS_TASK_OsTask_FG1_20ms_C1(void);
extern void OS_TASK_OsTask_FG1_20ms_C2(void);
extern void OS_TASK_OsTask_FG1_40ms_C0(void);
extern void OS_TASK_OsTask_FG1_50ms_C0(void);
extern void OS_TASK_OsTask_FG1_50ms_C1(void);
extern void OS_TASK_OsTask_FG1_5ms_C0(void);
extern void OS_TASK_OsTask_FG1_5ms_C1(void);
extern void OS_TASK_OsTask_IP_FG1_5ms_C0(void);
extern void OS_TASK_RteTask_FG1_1000ms_C0(void);
extern void OS_TASK_RteTask_FG1_1000ms_C1(void);
extern void OS_TASK_RteTask_FG1_100ms_C0(void);
extern void OS_TASK_RteTask_FG1_100ms_C1(void);
extern void OS_TASK_RteTask_FG1_100ms_C2(void);
extern void OS_TASK_RteTask_FG1_10ms_C0_A(void);
extern void OS_TASK_RteTask_FG1_10ms_C0_B(void);
extern void OS_TASK_RteTask_FG1_10ms_C1(void);
extern void OS_TASK_RteTask_FG1_10ms_C1_A(void);
extern void OS_TASK_RteTask_FG1_200ms_C0(void);
extern void OS_TASK_RteTask_FG1_200ms_C1(void);
extern void OS_TASK_RteTask_FG1_20ms_C0(void);
extern void OS_TASK_RteTask_FG1_20ms_C1(void);
extern void OS_TASK_RteTask_FG1_30ms_C0(void);
extern void OS_TASK_RteTask_FG1_30ms_C1(void);
extern void OS_TASK_RteTask_FG1_400ms_C1(void);
extern void OS_TASK_RteTask_FG1_40ms_C0(void);
extern void OS_TASK_RteTask_FG1_40ms_C1(void);
extern void OS_TASK_RteTask_FG1_500ms_C0(void);
extern void OS_TASK_RteTask_FG1_500ms_C1(void);
extern void OS_TASK_RteTask_FG1_50ms_C0(void);
extern void OS_TASK_RteTask_FG1_50ms_C1(void);
extern void OS_TASK_RteTask_FG1_5ms_C0(void);
extern void OS_TASK_RteTask_FG1_5ms_C1(void);
extern void OS_TASK_RteTask_FG1_80ms_C0(void);
extern void OS_TASK_RteTask_FG1_DataReceivedEvent_C2(void);
extern void OS_TASK_RteTask_FG1_InitEvent_C0(void);
extern void OS_TASK_RteTask_FG1_InitEvent_C1(void);
extern void OS_TASK_RteTask_FG1_InitEvent_C2(void);
#endif  /* MK_ASM */

/*===================================================================
 * Tasks_IDs
 *==================================================================*/
#define OsTask_FG1_BswEvent_C0  0
#define RteTask_FG1_DataReceivedEvent_C0  1
#define RteTask_FG1_DataReceivedEvent_C1  2
#define RteTask_FG1_ModeSwitchEvent_C0  3
#define RteTask_FG1_ModeSwitchEvent_C1  4
#define RteTask_FG1_ModeSwitchEvent_C2  5
#define RteTask_FG1_DataReceivedEvent_C1_A  6
#define RteTask_FG1_DataReceivedEvent_C1_B  7
#define RteTask_FG1_DataReceivedEvent_C1_C  8
#define RteTask_FG1_DataReceivedEvent_C1_D  9
#define Idle_Task_C0  10
#define Idle_Task_C1  11
#define Idle_Task_C2  12
#define Init_Task_C0  13
#define Init_Task_C1  14
#define Init_Task_C2  15
#define OsTask_FG1_1000ms_C0  16
#define OsTask_FG1_100ms_C0  17
#define OsTask_FG1_10ms_C0_A  18
#define OsTask_FG1_10ms_C0_B  19
#define OsTask_FG1_10ms_CAN_C0  20
#define OsTask_FG1_20ms_C0  21
#define OsTask_FG1_20ms_C1  22
#define OsTask_FG1_20ms_C2  23
#define OsTask_FG1_40ms_C0  24
#define OsTask_FG1_50ms_C0  25
#define OsTask_FG1_50ms_C1  26
#define OsTask_FG1_5ms_C0  27
#define OsTask_FG1_5ms_C1  28
#define OsTask_IP_FG1_5ms_C0  29
#define RteTask_FG1_1000ms_C0  30
#define RteTask_FG1_1000ms_C1  31
#define RteTask_FG1_100ms_C0  32
#define RteTask_FG1_100ms_C1  33
#define RteTask_FG1_100ms_C2  34
#define RteTask_FG1_10ms_C0_A  35
#define RteTask_FG1_10ms_C0_B  36
#define RteTask_FG1_10ms_C1  37
#define RteTask_FG1_10ms_C1_A  38
#define RteTask_FG1_200ms_C0  39
#define RteTask_FG1_200ms_C1  40
#define RteTask_FG1_20ms_C0  41
#define RteTask_FG1_20ms_C1  42
#define RteTask_FG1_30ms_C0  43
#define RteTask_FG1_30ms_C1  44
#define RteTask_FG1_400ms_C1  45
#define RteTask_FG1_40ms_C0  46
#define RteTask_FG1_40ms_C1  47
#define RteTask_FG1_500ms_C0  48
#define RteTask_FG1_500ms_C1  49
#define RteTask_FG1_50ms_C0  50
#define RteTask_FG1_50ms_C1  51
#define RteTask_FG1_5ms_C0  52
#define RteTask_FG1_5ms_C1  53
#define RteTask_FG1_80ms_C0  54
#define RteTask_FG1_DataReceivedEvent_C2  55
#define RteTask_FG1_InitEvent_C0  56
#define RteTask_FG1_InitEvent_C1  57
#define RteTask_FG1_InitEvent_C2  58

/*===================================================================
 * User Function Declarations
 *==================================================================*/
#ifndef MK_ASM

#endif  /* MK_ASM */
#ifdef __cplusplus
}
#endif
#endif  /* MK_GEN_USER_H */
