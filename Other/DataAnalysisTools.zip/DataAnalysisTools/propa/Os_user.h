/* This file is generated automatically. DO NOT EDIT!!
 *
 * EB tresos AutoCore OS 6.1.138 CORTEXM/S32G399
 * (Build 20230216)
 *
 * (c) 1998-2023 Elektrobit Automotive GmbH
 * Am Wolfsmantel 46
 * 91058 Erlangen
 * GERMANY
 *
 * Date         : 5/10/23 2:00 PM           !!!IGNORE-LINE!!!
 */

#ifndef OS_USER_H
#define OS_USER_H
#ifdef __cplusplus
extern "C" {
#endif

#define OS_GENERATION_ID_OS_H    0x24a2c2d2UL

#define OS_AUTOSAROS_VER         6

#define OS_AUTOSAROS_REV         1

#define OS_AUTOSAROS_CORE_BUILD  20230216

#define OS_AUTOSAROS_ARCH_BUILD  20230216

#ifndef OS_INTERRUPT_KEYWORD
#define OS_INTERRUPT_KEYWORD
#endif

#include <Os_api.h>

/*===================================================================
 * Alarms
 *==================================================================*/
#define AlarmIncrementRteCounter  0

/*===================================================================
 * Application modes
 *==================================================================*/
#define OSDEFAULTAPPMODE  0

/*===================================================================
 * Applications
 *==================================================================*/
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define OsApplication_C3  0
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define OsApplication_Stub  1
#endif
/* Application Hooks */
/* Trusted Functions */

/*===================================================================
 * CPU Core configuration
 *==================================================================*/
#define OS_CORE_ID_0  0
#define OS_CORE_ID_1  1
#define OS_CORE_ID_2  2
#define OS_CORE_ID_3  3

/*===================================================================
 * Core Mapping
 *==================================================================*/
#define RES_SCHEDULER  0u

/*===================================================================
 * Counters
 *==================================================================*/
/* Macros for the configured counter values and time conversions */
#define OSMAXALLOWEDVALUE_Rte_Counter_C3  OS_U(4294967295)
#define OSTICKSPERBASE_Rte_Counter_C3  OS_U(1)
#define OSMINCYCLE_Rte_Counter_C3  OS_U(1)
#define OS_NsToTicks_Rte_Counter_C3(x)  ((x)/1000000)
#define OS_TicksToNs_Rte_Counter_C3(x)  ((x)*1000000)
#define OS_TICKS2NS_Rte_Counter_C3(x)   (OS_TicksToNs_Rte_Counter_C3((x)))
#define OS_TICKS2US_Rte_Counter_C3(x)   (OS_TicksToNs_Rte_Counter_C3((x)))/1000u
#define OS_TICKS2MS_Rte_Counter_C3(x)   (OS_TicksToNs_Rte_Counter_C3((x)))/1000000u
#define OS_TICKS2SEC_Rte_Counter_C3(x)  (OS_TicksToNs_Rte_Counter_C3((x)))/1000000000u
#define OSMAXALLOWEDVALUE_HwCounter_C3  OS_U(4294967295)
#define OSTICKSPERBASE_HwCounter_C3  OS_U(1000)
#define OSMINCYCLE_HwCounter_C3  OS_U(1)
#ifndef OS_ASM
extern void OS_CounterIsr_HwCounter_C3(void);
#endif  /* OS_ASM */
#define OS_NsToTicks_HwCounter_C3(x)  OS_NsToTicks_STM4_0((x))
#define OS_TicksToNs_HwCounter_C3(x)  OS_TicksToNs_STM4_0((x))
#define OS_TICKS2NS_HwCounter_C3(x)   (OS_TicksToNs_STM4_0((x)))
#define OS_TICKS2US_HwCounter_C3(x)   (OS_TicksToNs_STM4_0((x))/1000u)
#define OS_TICKS2MS_HwCounter_C3(x)   (OS_TicksToNs_STM4_0((x))/1000000u)
#define OS_TICKS2SEC_HwCounter_C3(x)  (OS_TicksToNs_STM4_0((x))/1000000000u)
#define OSMAXALLOWEDVALUE_Rte_Counter_Stub  OS_U(4294967295)
#define OSTICKSPERBASE_Rte_Counter_Stub  OS_U(1)
#define OSMINCYCLE_Rte_Counter_Stub  OS_U(1)
#define OS_NsToTicks_Rte_Counter_Stub(x)  ((x)/1000000)
#define OS_TicksToNs_Rte_Counter_Stub(x)  ((x)*1000000)
#define OS_TICKS2NS_Rte_Counter_Stub(x)   (OS_TicksToNs_Rte_Counter_Stub((x)))
#define OS_TICKS2US_Rte_Counter_Stub(x)   (OS_TicksToNs_Rte_Counter_Stub((x)))/1000u
#define OS_TICKS2MS_Rte_Counter_Stub(x)   (OS_TicksToNs_Rte_Counter_Stub((x)))/1000000u
#define OS_TICKS2SEC_Rte_Counter_Stub(x)  (OS_TicksToNs_Rte_Counter_Stub((x)))/1000000000u

/* Non-Internal Counter Ids */
#define Rte_Counter_C3  0
#define HwCounter_C3  1
#define Rte_Counter_Stub  2


/* System Counter Macros */
#define OSMAXALLOWEDVALUE  OSMAXALLOWEDVALUE_HwCounter_C3
#define OSTICKSPERBASE     OSTICKSPERBASE_HwCounter_C3
#define OSMINCYCLE         OSMINCYCLE_HwCounter_C3
#define OSTICKDURATION     OS_TicksToNs_HwCounter_C3(1u)

/*===================================================================
 * Events
 *==================================================================*/
#define SchM_OSShutdownEvent  0x0001u
#define Rte_OSShutdownEvent  0x0001u
#define Rte_OSTriggerExecutableEvent_OsTask_FG1_BswEvent_IRTRIGGER_CD3C910658C12D0BB9B209C420BF92B8  0x0002u
#define Rte_OSTriggerExecutableEvent_OsTask_FG1_BswEvent_IRTRIGGER_CB505970F5C130A9414DB605B7F8C5EF  0x0004u
#define Rte_OSTriggerExecutableEvent_OsTask_FG1_BswEvent_IRTRIGGER_5641CFCE977E8D881DEEC85973C800AB  0x0008u
#define Rte_OSTriggerExecutableEvent  0x0002u

/*===================================================================
 * Interrupts
 *==================================================================*/
#ifndef OS_ASM
extern void OS_ISR_Eth_43_PFE_HifIrqHdlr_1(void);
#endif  /* OS_ASM */
#define Eth_43_PFE_HifIrqHdlr_1_ISR_CATEGORY  2
#define Eth_43_PFE_HifIrqHdlr_1_ISR_VECTOR    191
#define Eth_43_PFE_HifIrqHdlr_1_ISR_LEVEL     7
#ifndef OS_ASM
extern void OS_ISR_Can_FifoRxInNotEmptyIsr_8_15(void);
#endif  /* OS_ASM */
#define Can_FifoRxInNotEmptyIsr_8_15_ISR_CATEGORY  2
#define Can_FifoRxInNotEmptyIsr_8_15_ISR_VECTOR    175
#define Can_FifoRxInNotEmptyIsr_8_15_ISR_LEVEL     7
#ifndef OS_ASM
extern void OS_ISR_Can_FifoRxOutNotEmptyIsr_8_15(void);
#endif  /* OS_ASM */
#define Can_FifoRxOutNotEmptyIsr_8_15_ISR_CATEGORY  2
#define Can_FifoRxOutNotEmptyIsr_8_15_ISR_VECTOR    177
#define Can_FifoRxOutNotEmptyIsr_8_15_ISR_LEVEL     7
#ifndef OS_ASM
extern void OS_ISR_Can_FifoTxAckNotEmptyIsr_8_15(void);
#endif  /* OS_ASM */
#define Can_FifoTxAckNotEmptyIsr_8_15_ISR_CATEGORY  2
#define Can_FifoTxAckNotEmptyIsr_8_15_ISR_VECTOR    183
#define Can_FifoTxAckNotEmptyIsr_8_15_ISR_LEVEL     7
#ifndef OS_ASM
extern void OS_ISR_OsIsr_MSCM_INT3_IRQn(void);
#endif  /* OS_ASM */
#define OsIsr_MSCM_INT3_IRQn_ISR_CATEGORY  2
#define OsIsr_MSCM_INT3_IRQn_ISR_VECTOR    22
#define OsIsr_MSCM_INT3_IRQn_ISR_LEVEL     4
#ifndef OS_ASM
extern void OS_ISR_OsIsr_MSCM_INT6_IRQn(void);
#endif  /* OS_ASM */
#define OsIsr_MSCM_INT6_IRQn_ISR_CATEGORY  2
#define OsIsr_MSCM_INT6_IRQn_ISR_VECTOR    69
#define OsIsr_MSCM_INT6_IRQn_ISR_LEVEL     4
#define Os_Counter_STM4_0_ISR_CATEGORY  2
#define Os_Counter_STM4_0_ISR_VECTOR    28
#define Os_Counter_STM4_0_ISR_LEVEL     2
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Eth_43_PFE_HifIrqHdlr_1  0
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Can_FifoRxInNotEmptyIsr_8_15  1
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Can_FifoRxOutNotEmptyIsr_8_15  2
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Can_FifoTxAckNotEmptyIsr_8_15  3
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define OsIsr_MSCM_INT3_IRQn  4
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define OsIsr_MSCM_INT6_IRQn  5
#endif

/*===================================================================
 * Resources
 *==================================================================*/
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RES_SCHEDULER_3  0
#endif

/*===================================================================
 * Schedule Tables
 *==================================================================*/
#define SchM_DefaultScheduleTable_OsApplication_C3  0
#define Rte_DefaultScheduleTable_OsApplication_C3  1

/*===================================================================
 * Spinlocks
 *==================================================================*/

/*===================================================================
 * Tasks
 *==================================================================*/
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define OsTask_FG1_BswEvent  0
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_DataReceivedEvent  1
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Init_Task  2
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_InitEvent  3
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define OsTask_FG1_5ms  4
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define OsTask_FG1_10ms  5
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define OsTask_FG1_20ms_A  6
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define OsTask_FG1_20ms_B  7
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define OsTask_FG1_20ms_C  8
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define OsTask_FG1_50ms  9
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define OsTask_FG1_100ms_A  10
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define OsTask_FG1_100ms_B  11
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define OsTask_FG1_100ms_C  12
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define OsTask_FG1_100ms_D  13
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define OsTask_FG1_100ms_E  14
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_5ms_A  15
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_5ms_B  16
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_10ms_A  17
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_10ms_B  18
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_20ms_A  19
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_20ms_B  20
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_30ms  21
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_40ms_A  22
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_40ms_B  23
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_40ms_C  24
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_50ms  25
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_80ms  26
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_100ms_A  27
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_100ms_B  28
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_100ms_C  29
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_100ms_D  30
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_500ms  31
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RteTask_FG1_1000ms  32
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Idle_Task  33
#endif

/*===================================================================
 * Time-stamp timer
 *==================================================================*/
#define OS_TimestampNsToTicks(ns)     OS_NsToTicks_TbTimer(ns)
#define OS_TimestampTicksToNs(ticks)  OS_TicksToNs_TbTimer(ticks)
#ifdef __cplusplus
}
#endif
#endif  /* OS_USER_H */
