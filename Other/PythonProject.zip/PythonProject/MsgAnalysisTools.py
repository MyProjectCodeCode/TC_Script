#!/usr/bin/python
# -*- coding:utf-8 -*-

#Author: Liu Qi 
#Version : v1.0

'''
The latest version of xlrd cannot parse xlsx, only xls can be parsed, 
and an old version of 1.2.0 needs to be installed and used

Command:
pip uninstall xlrd
pip install xlrd==1.2.0
'''
import sys,xlrd,os,re
from openpyxl import Workbook
import pdfplumber

Mode = sys.argv[1]
CMX_file = sys.argv[2]

curr_work_dir = os.path.dirname(__file__)                                 #get the absolute path of the current py file
CMX_name = re.sub('[\u4e00-\u9fa5]','',os.path.basename(CMX_file))        #get the file name of the CMX table (excluding Chinese characters)
folder_name = CMX_name[:3]                                                #get the first 3 characters (project name) as the folder name

CinFileRrefix = '/*@!Encoding:1252*/\nincludes\n{\n  #include "../' + folder_name + '_Public.cin"\n}\n\n// ************************* '+  CMX_name + ' *************************\n\n'

CMXxlsx = xlrd.open_workbook(CMX_file)
RoutingChart = CMXxlsx.sheet_by_name("GWRoutingChart")

RoutingChart_Arr = []
Tx_Chn_Arr = []

SrcMsgColNum = 2
DestMsgColNum = 38
MsgIDColNum = 40
llceValColNum = 13
ChnStartColNum = 16
ChnEndColNum = 27
ChnNameRowNum = 3

#Create a folder with the project name (A02 A09 or AH8)
def CreateFolder(FolderName):
  FolderPath = curr_work_dir + '/' + FolderName
  if not os.path.exists(FolderPath):
    os.mkdir(curr_work_dir + '/' + FolderName)  #Create a folder in the current py file directory

def removeArrDupValue(arr):
  return(list(set(arr)))

def getTxSheet():
  Tx_sheetNameArr = []  #Store all sheet names starting with Tx in the CMX table
  all_sheet_names = CMXxlsx.sheet_names()

  for sheet_name in all_sheet_names:
    if sheet_name[:3] == 'Tx_':
      Tx_sheetNameArr.append(sheet_name)
  
  return(Tx_sheetNameArr)

def getNoTestId():
  
  NoTest_idArr = []  #An array storing POE PA or Event type IDs
  
  for sheetNameStr in getTxSheet():
    Tx_sheet = CMXxlsx.sheet_by_name(sheetNameStr)
    for i in range(Tx_sheet.nrows):
      MsgSendType = Tx_sheet.cell_value(i,4)
      if MsgSendType == 'POE' or MsgSendType == 'PA' or MsgSendType == 'Event':
        NoTest_idArr.append(Tx_sheet.cell_value(i,2).replace(' ',''))
  
  NoTest_idArr = removeArrDupValue(NoTest_idArr)
  return(NoTest_idArr)

def getLLCEMsgID():
  LLCE_idArr = []
  for i in range(RoutingChart.nrows):
    llce_value = RoutingChart.cell_value(i,llceValColNum)
    if llce_value == 1:
      LLCE_idArr.append(RoutingChart.cell_value(i,MsgIDColNum).replace(' ','')) #replace : Remove Str spaces

  LLCE_idArr = removeArrDupValue(LLCE_idArr)
  return(LLCE_idArr)

def getTestID(NoTest_Arr,LLCE_Arr):
  Test_idArr = [x for x in LLCE_Arr if x not in NoTest_Arr]
  return(Test_idArr)

def CreateCinFileWrite():
  global Tx_Chn_Arr
  for Tx_sheetName in getTxSheet():
    ChnName = Tx_sheetName[3:]
    Tx_Chn_Arr.append(Switch_Case(ChnName))
    CinName = ChnName + '.cin'
    file = open(curr_work_dir + '/' + folder_name + '/' + CinName,'w')
    file.write(CinFileRrefix)
    file.close()

def SearchSourceChn(RowNum):
  SrcCol = 0

  for SrcCol in range(ChnStartColNum,ChnEndColNum+1):
    if RoutingChart.cell_value(RowNum,SrcCol).replace(' ','') == 'S':
      break;
  return(RoutingChart.cell_value(ChnNameRowNum,SrcCol).replace(' ',''))

def SearchDestChn(RowNum):
  dest_arr = []

  for DestCol in range(ChnStartColNum,ChnEndColNum+1):
    if RoutingChart.cell_value(RowNum,DestCol).replace(' ','') == 'D':
      dest_arr.append(Switch_Case(RoutingChart.cell_value(ChnNameRowNum,DestCol).replace(' ','')))

  return(dest_arr)

def WriteIDtoCin(index,fileName,_id,SrcMsgStr,DestMsgStr):
  filepath = curr_work_dir + '/' + folder_name + '/' + fileName + '.cin'
  file = open(filepath,'a')
  file.write('//Src : ' + SrcMsgStr + ' ; ' + 'Dest : ' + DestMsgStr + '\non message ' + str(_id) + '\n{\n' + '  if(StartTestFlag) MsgOpera(this.simulated,MonitorFlag[' + str(index) +'],this.can,' + fileName +',this.id,DestChnArr[' + str(index) + '],CurrDestNum[' + str(index) + '],ExpChnArr_' + str(_id) + ',SrcBusTime[' + str(index) + '],DestBusTime[' + str(index) + '],ReturnCodeNumArr[' + str(index) + '],FrameRoutingArr_' + str(_id) + ');\n}\n\n')
  file.close()

def getMsgRoutingDestChn(_id):
  LLCE_RowNum = 0
  CurrIDdest_arr = []
  for i in range(RoutingChart.nrows):
    if RoutingChart.cell_value(i,1).replace(' ','')[:4] == 'LLCE':
      LLCE_RowNum = i
      break
  
  for i in range(LLCE_RowNum):
    Currid = RoutingChart.cell_value(i,MsgIDColNum).replace(' ','')
    CurrLLce = RoutingChart.cell_value(i,llceValColNum)
    if Currid == _id and CurrLLce == 0:
      for destNum in SearchDestChn(i):
        CurrIDdest_arr.append(destNum)

  return(removeArrDupValue(CurrIDdest_arr))

def WriteParameter():

  ID_ArrStr = ''
  for i in range(len(RoutingChart_Arr)):
    Currid = RoutingChart_Arr[i][1]
    ID_ArrStr += str(Currid) + ','

  Tx_Chn_Arr.sort()
  
  Parameterfilepath = curr_work_dir + '/' + folder_name + '/Parameter.cin'
  file = open(Parameterfilepath,'w')
  file.write('/*@!Encoding:1252*/\nvariables\n{\n  // ************************* '+  CMX_name + ' *************************\n\n')

  for ChnNum in Tx_Chn_Arr:
    file.write('  // ' + ChnConver(ChnNum) + ' (CAN' + str(ChnNum) + ')\n')
    for i in range(len(RoutingChart_Arr)):
      if RoutingChart_Arr[i][0] == ChnNum:
        Currid = RoutingChart_Arr[i][1]
        Arrlen = len(RoutingChart_Arr[i])
        CurridDestNum = Arrlen - 2
        CurridDestChn = RoutingChart_Arr[i][2:Arrlen]
        MsgRoutingDestChnStr = getMsgRoutingDestChn(Currid)
        MsgRouDestStr = ''
        if len(MsgRoutingDestChnStr) == 0:
          MsgRouDestStr = '[1] = {-1};\n'
        else:
          MsgRouDestStr = '[' + str(len(MsgRoutingDestChnStr)) + '] = {' + str(MsgRoutingDestChnStr)[1:-1].replace(' ','') + '};\n'

        file.write('  int ExpChnArr_' + str(Currid) + '[' + str(CurridDestNum) + '] = {' + str(CurridDestChn)[1:-1].replace(' ','') + '};  int FrameRoutingArr_' + str(Currid) + MsgRouDestStr)
    file.write('\n')
        
  file.write('  const int RoutingMsgNum = ' + str(TestID_Count) + ';\n')
  file.write('  double SrcBusTime[RoutingMsgNum];\n')
  file.write('  double DestBusTime[RoutingMsgNum];\n')
  file.write('  int DestChnArr[RoutingMsgNum][10];\n')
  file.write('  int CurrDestNum[RoutingMsgNum];\n')
  file.write('  byte MonitorFlag[RoutingMsgNum];\n')
  file.write('  dword ReturnCodeNumArr[RoutingMsgNum][2];\n')

  file.write('  int TestID_Arr[RoutingMsgNum] = {' + ID_ArrStr[:-1] + '};\n')
  file.write('}\n')
  file.close()

def Switch_Case(ChnName):
  ChnNum = 0
  if ChnName == 'Public_CANFD1':
    ChnNum = 1
  elif ChnName == 'CCU_CANFD2':
    ChnNum = 3
  elif ChnName == 'CCU_CANFD4':
    ChnNum = 4
  elif ChnName == 'CCU_CANFD3':
    ChnNum = 6
  elif ChnName == 'CZF_CANFD':
    ChnNum = 8
  elif ChnName == 'CZL_CANFD':
    ChnNum = 9
  elif ChnName == 'CZR_CANFD':
    ChnNum = 10
  elif ChnName == 'CZT_CANFD':
    ChnNum = 11
  elif ChnName == 'CIDC_CANFD':
    ChnNum = 12
  elif ChnName == 'CCU_CANFD1':
    ChnNum = 13
  elif ChnName == 'Public_CANFD2':
    ChnNum = 15
  elif ChnName == 'TBOX_CANFD':
    ChnNum = 16

  return(ChnNum)

def ChnConver(ChnNum):
  if ChnNum == 1:
    return('Public_CANFD1')
  elif ChnNum == 3:
    return('CCU_CANFD2')
  elif ChnNum == 4:
    return('CCU_CANFD4')
  elif ChnNum == 6:
    return('CCU_CANFD3')
  elif ChnNum == 8:
    return('CZF_CANFD')
  elif ChnNum == 9:
    return('CZL_CANFD')
  elif ChnNum == 10:
    return('CZR_CANFD')
  elif ChnNum == 11:
    return('CZT_CANFD')
  elif ChnNum == 12:
    return('CIDC_CANFD')
  elif ChnNum == 13:
    return('CCU_CANFD1')
  elif ChnNum == 15:
    return('Public_CANFD2')
  elif ChnNum == 16:
    return('TBOX_CANFD')

def SearchSrcDestMsgName(_id):
  MsgNameStrArr = []
  for i in range(RoutingChart.nrows):
    if RoutingChart.cell_value(i,MsgIDColNum).replace(' ','') == _id:
      MsgNameStrArr.append(RoutingChart.cell_value(i,SrcMsgColNum).replace(' ',''))
      MsgNameStrArr.append(RoutingChart.cell_value(i,DestMsgColNum).replace(' ',''))
      break;
  return(MsgNameStrArr)

def WriteInXlsx():
  FirstRowsArr = ['No.','Src Message','Src Chn','Dest Message','Dest Chn','ID']
  xlsx_workbook = Workbook()
  sheet = xlsx_workbook.active
  for i in range(len(FirstRowsArr)):
    sheet.cell(row=1,column=i+1,value=FirstRowsArr[i])
  
  for i in range(TestID_Count):
    SrcChnNum = RoutingChart_Arr[i][0]
    _id = RoutingChart_Arr[i][1]
    CurrDestStrArr = ''
    sheet.cell(row=i+2,column=1,value=str(i+1))
    sheet.cell(row=i+2,column=2,value=SearchSrcDestMsgName(_id)[0])
    sheet.cell(row=i+2,column=3,value=ChnConver(SrcChnNum)+'(CAN'+str(SrcChnNum)+')')
    sheet.cell(row=i+2,column=4,value=SearchSrcDestMsgName(_id)[1])

    for j in range(2,len(RoutingChart_Arr[i])):
      DestChnNum = RoutingChart_Arr[i][j]
      CurrDestStrArr += ChnConver(DestChnNum)+'(CAN'+str(DestChnNum)+'),'

    sheet.cell(row=i+2,column=5,value=CurrDestStrArr[:-1])
    sheet.cell(row=i+2,column=6,value=str(_id))
    
  xlsx_workbook.save(curr_work_dir + '/' + folder_name + '_RoutingChart.xlsx')

def SearchMsg(MsgName):
  MsgStrArr = []
  for sheetNameStr in getTxSheet():
    Tx_sheet = CMXxlsx.sheet_by_name(sheetNameStr)
    ChnName = sheetNameStr[3:]
    for i in range(Tx_sheet.nrows):
      CurrMsgName = Tx_sheet.cell_value(i,1).replace(' ','')
      if CurrMsgName == MsgName:
        MsgStrArr.append('{"'+ChnName+'::'+CurrMsgName+'"},')
  
  return(removeArrDupValue(MsgStrArr))

def DeleteArrLastChar(arr):
  arr[len(arr)-1] = arr[len(arr)-1][:-1]
  return(arr)

def SearchDeleteMsg():
  DeleteArr = []

  for i in range(RoutingChart.nrows):
    llce_value = RoutingChart.cell_value(i,llceValColNum)
    if llce_value == 0:
      _id = RoutingChart.cell_value(i,MsgIDColNum).replace(' ','')
      destChnNumArr = SearchDestChn(i)
      for DestChnNum in destChnNumArr:
        ChnName = ChnConver(DestChnNum)
        sheetName = 'Tx_' + ChnName
        CurrTxsheet = CMXxlsx.sheet_by_name(sheetName)
        for j in range(CurrTxsheet.nrows):
          CurrSheetId = CurrTxsheet.cell_value(j,2).replace(' ','')
          ECU_Tx = CurrTxsheet.cell_value(j,0).replace(' ','')
          signalname = CurrTxsheet.cell_value(j,1).replace(' ','')
          if CurrSheetId == _id and ECU_Tx == 'CCU':
            DeleteArr.append('{"' + ChnName + '::' + signalname + '"},')
            break

  return(DeleteArr)

def fix_hex_string(string):
  if string.startswith('0X'):
    string = string.replace('0X','0x',1)
  return(string)
            
def PDF_analysis():
  DataID_Arr = []

  with pdfplumber.open(PDF_FileName) as pdf:
    
    for i in range(1,len(pdf.pages)):
      pageText = pdf.pages[i].extract_tables()[0]
      ID_Data = [row[3] for row in pageText]
      for dataid in ID_Data:
        if (str(dataid)[:2] == '0x' or str(dataid)[:2] == '0X') and len(str(dataid)) == 5:
          DataID_Arr.append(fix_hex_string(str(dataid)))
  
  return(removeArrDupValue(DataID_Arr))

def ID_Confirm(_id,Arr):
  if _id in Arr:
    return True
  else:
    return False

def MsgClassify():
  
  RoutingMsgArr = []
  E2EMsgArr = []
  allMsgStrArr = []  #An array storing POE PA or Event type IDs

  txtfilePath = curr_work_dir + '/' + folder_name + '_message_classify.txt'
  txtfile = open(txtfilePath,'w')
  txtfile.write('########## ' + CMX_name + ' ##########\n\n')

  ####################### 0.all message ########################

  for sheetNameStr in getTxSheet():
    Tx_sheet = CMXxlsx.sheet_by_name(sheetNameStr)
    ChnName = sheetNameStr[3:]
    for i in range(Tx_sheet.nrows):
      MsgSendType = Tx_sheet.cell_value(i,4).replace(' ','')
      if MsgSendType == 'Periodic':
        Str = '{"' + ChnName + '::' + Tx_sheet.cell_value(i,1).replace(' ','') + '"},'
        allMsgStrArr.append(Str)

  allMsgStrArr = removeArrDupValue(allMsgStrArr)
  
  ####################### 1.Routing message ########################

  for i in range(TestID_Count):
    _id = RoutingChart_Arr[i][1]
    DestMessage = SearchSrcDestMsgName(_id)[1]
    for j in range(2,len(RoutingChart_Arr[i])):
      DestChnNum = RoutingChart_Arr[i][j]
      CurrDestStrArr = '{"'+ChnConver(DestChnNum)+'::'+DestMessage+'"},'
      RoutingMsgArr.append(CurrDestStrArr)

  ####################### 2.NM message ########################

  NMMsgArr = SearchMsg('CCU_NM')

  ####################### 3.TimeSync message ########################

  TimeSyncMsgArr = SearchMsg('CCU_TimeSync')

  ####################### 4.E2E message ########################

  E2E_DataID_Arr = PDF_analysis()

  for sheetNameStr in getTxSheet():
    Tx_sheet = CMXxlsx.sheet_by_name(sheetNameStr)
    ChnName = sheetNameStr[3:]
    RemarkColNum = 0
    
    for i in range(Tx_sheet.ncols):  #get Remark column value
      if Tx_sheet.cell_value(1,i).replace(' ','') == 'Remark':
        RemarkColNum = i
        break
    
    for j in range(Tx_sheet.nrows):
      SignalName = Tx_sheet.cell_value(j,8).replace(' ','')
      RemarkValue = Tx_sheet.cell_value(j,RemarkColNum).replace(' ','')
      ECU_Tx = Tx_sheet.cell_value(j,0).replace(' ','')
      _id = Tx_sheet.cell_value(j,2).replace(' ','')

      if SignalName[-4:] == '_CRC' and RemarkValue[:10] == '<E2E_Group' and (ECU_Tx == 'CCURT1' or ECU_Tx == 'CCURT2') and ID_Confirm(_id,E2E_DataID_Arr) == True:
        CurrMsgName = Tx_sheet.cell_value(j,1).replace(' ','')
        E2EMsgArr.append('{"'+ChnName+'::'+CurrMsgName+'"},')

  ####################### 5.delete message ########################

  DeleteArr = removeArrDupValue(SearchDeleteMsg())

  ####################### 6.periodic message ########################

  Periodic_Arr = getTestID(E2EMsgArr,getTestID(DeleteArr,getTestID(TimeSyncMsgArr,getTestID(NMMsgArr,getTestID(RoutingMsgArr,allMsgStrArr)))))

  #################################  Write in txt file #####################################
  
  txtfile.write('const int TestGroupCount_Routing = ' + str(len(RoutingMsgArr)) + ';\n')
  txtfile.write('const int TestGroupCount_E2E = ' + str(len(E2EMsgArr)) + ';\n')
  txtfile.write('const int TestGroupCount_NM = ' + str(len(NMMsgArr)) + ';\n')
  txtfile.write('const int TestGroupCount_TimeSync = ' + str(len(TimeSyncMsgArr)) + ';\n')
  txtfile.write('const int TestGroupCount_Delete = ' + str(len(DeleteArr)) + ';\n')
  txtfile.write('const int TestGroupCount_Periodic = ' + str(len(Periodic_Arr)) + ';\n\n')

  txtfile.write('struct CAN_FRAME_MSG_STRUCT TestGroup_Routing[TestGroupCount_Routing] = \n{\n  ')
  for msg in DeleteArrLastChar(RoutingMsgArr):
    txtfile.write(msg)
  txtfile.write('\n};\n\n')

  txtfile.write('struct CAN_FRAME_MSG_STRUCT TestGroup_E2E[TestGroupCount_E2E] = \n{\n  ')
  for msg in DeleteArrLastChar(E2EMsgArr):
    txtfile.write(msg)
  txtfile.write('\n};\n\n')

  txtfile.write('struct CAN_FRAME_MSG_STRUCT TestGroup_NM[TestGroupCount_NM] = \n{\n  ')
  for msg in DeleteArrLastChar(NMMsgArr):
    txtfile.write(msg)
  txtfile.write('\n};\n\n')

  txtfile.write('struct CAN_FRAME_MSG_STRUCT TestGroup_TimeSync[TestGroupCount_TimeSync] = \n{\n  ')
  for msg in DeleteArrLastChar(TimeSyncMsgArr):
    txtfile.write(msg)
  txtfile.write('\n};\n\n')

  txtfile.write('struct CAN_FRAME_MSG_STRUCT TestGroup_Delete[TestGroupCount_Delete] = \n{\n  ')
  for msg in DeleteArrLastChar(DeleteArr):
    txtfile.write(msg)
  txtfile.write('\n};\n\n')

  txtfile.write('struct CAN_FRAME_MSG_STRUCT TestGroup_Periodic[TestGroupCount_Periodic] = \n{\n  ')
  for msg in DeleteArrLastChar(Periodic_Arr):
    txtfile.write(msg)
  txtfile.write('\n};\n\n')

  txtfile.close()

def ID_SrcDestChnAnalysis():
  global TestID_Count
  global RoutingChart_Arr
  TestID_Arr = getTestID(getNoTestId(),getLLCEMsgID())
  TestID_Count = len(TestID_Arr)
  
  StartPoint = 0
  index = 0
  fileName = ''
  SrcMsgStr = ''
  DestMsgStr = ''

  for test_id in TestID_Arr:
    CurrDestArr = []
    Sub_arr = []

    for i in range(RoutingChart.nrows):
      _id = RoutingChart.cell_value(i,MsgIDColNum).replace(' ','')
      llce_value = RoutingChart.cell_value(i,llceValColNum)
      if test_id == _id and llce_value == 1:
        fileName = SearchSourceChn(i)
        SrcMsgStr = RoutingChart.cell_value(i,SrcMsgColNum).replace(' ','')
        DestMsgStr = RoutingChart.cell_value(i,DestMsgColNum).replace(' ','')
        StartPoint = i
        break;

    for i in range(StartPoint,RoutingChart.nrows):
      _id = RoutingChart.cell_value(i,MsgIDColNum).replace(' ','')
      llce_value = RoutingChart.cell_value(i,llceValColNum)
      if test_id == _id and llce_value == 1:
        for destchn in SearchDestChn(i):
          CurrDestArr.append(destchn)

    Sub_arr.append(Switch_Case(fileName))
    Sub_arr.append(test_id)

    for destChn in removeArrDupValue(CurrDestArr):
      Sub_arr.append(destChn)

    RoutingChart_Arr.append(Sub_arr)
    
    if Mode == '-t':
      WriteIDtoCin(index,fileName,test_id,SrcMsgStr,DestMsgStr)
    index += 1

def getAllMsgWriteInTxt():
  txtfilePath = curr_work_dir + '/' + folder_name + '_all_message.txt'
  txtfile = open(txtfilePath,'w')
  txtfile.write('########## ' + CMX_name + ' ##########\n\n')
  TotalNum = 0
  index = 1

  for sheetNameStr in getTxSheet():
    allMsgStrArr = []  #An array storing POE PA or Event type IDs
    Tx_sheet = CMXxlsx.sheet_by_name(sheetNameStr)
    ChnName = sheetNameStr[3:]
    for i in range(Tx_sheet.nrows):
      MsgSendType = Tx_sheet.cell_value(i,4).replace(' ','')
      if MsgSendType == 'Periodic':
        Str = '{"' + ChnName + '::' + Tx_sheet.cell_value(i,1).replace(' ','') + '"},'
        allMsgStrArr.append(Str)
    
    txtfile.write(ChnName + '[' + str(len(removeArrDupValue(allMsgStrArr))) + '] :\n\n')

    if index != len(getTxSheet()):
      for name in removeArrDupValue(allMsgStrArr):
        txtfile.write(name)
    else:
      for name in DeleteArrLastChar(removeArrDupValue(allMsgStrArr)):
        txtfile.write(name)

    txtfile.write('\n\n')
    TotalNum += len(removeArrDupValue(allMsgStrArr))
    index += 1

  txtfile.write('########## Total : ' + str(TotalNum)  + ' ##########\n')
  txtfile.close()

def ArrOpera(Arr):
  OperaArr = []
  for msg in Arr:
    OperaArr.append(msg[2:-3])
  return(OperaArr)

def getMsgCycTimeNum(Msg):
  CycTime = ''
  MsgChn = Msg.split('::')[0]
  MsgName = Msg.split('::')[-1]
  CurrSheet = 'Tx_' + MsgChn
  Tx_sheet = CMXxlsx.sheet_by_name(CurrSheet)

  for i in range(Tx_sheet.nrows):
    if Tx_sheet.cell_value(i,1).replace(' ','') == MsgName:
      CycTime = str(Tx_sheet.cell_value(i,5)).replace(' ','')
      break

  return(CycTime)

def getMsgCounterFrameName(Msg):
  CounterName = ''
  MsgChn = Msg.split('::')[0]
  MsgName = Msg.split('::')[-1]
  CurrSheet = 'Tx_' + MsgChn
  Tx_sheet = CMXxlsx.sheet_by_name(CurrSheet)

  for i in range(Tx_sheet.nrows):
    if Tx_sheet.cell_value(i,1).replace(' ','') == MsgName and Tx_sheet.cell_value(i,8).replace(' ','')[-8:] == '_Counter':
      CounterName = Tx_sheet.cell_value(i,8).replace(' ','')
      break
  return(CounterName)

def getMsgID(Msg):
  MsgID = ''
  MsgChn = Msg.split('::')[0]
  MsgName = Msg.split('::')[-1]
  CurrSheet = 'Tx_' + MsgChn
  Tx_sheet = CMXxlsx.sheet_by_name(CurrSheet)

  for i in range(Tx_sheet.nrows):
    if Tx_sheet.cell_value(i,1).replace(' ','') == MsgName:
      MsgID = Tx_sheet.cell_value(i,2).replace(' ','')
      break
  return(MsgID)
  
def getCCUSendFrame():
  txtfilePath = curr_work_dir + '/' + folder_name + '_CCUSendFrame.txt'
  txtfile = open(txtfilePath,'w')
  txtfile.write('########## ' + CMX_name + ' ##########\n\n')

  TotalNum = 0
  index = 1
  CounterMsgNum = 0
  CycTimeMsgNum = 0
  NumIndex = 0
  CounterIndex = 0
  TimeIndex = 0
  TestMsgIDStrArr = []
  TestMsgNameStrArr = []

  for sheetNameStr in getTxSheet():

    CCUSendFrameArr = []
    CounterMsgNameArr = []
    CycTimeMsgNameArr = []

    Tx_sheet = CMXxlsx.sheet_by_name(sheetNameStr)
    ChnName = sheetNameStr[3:]
    CinName = ChnName + '.cin'
    file = open(curr_work_dir + '/' + folder_name + '_PacketLossChk/' + CinName,'w')
    file.write('/*@!Encoding:1252*/\nincludes\n{\n  #include "../' + folder_name + '_PacketLossChk_PublicFn.cin"\n}\n\n// ************************* '+  CMX_name + ' *************************\n\n')

    for i in range(Tx_sheet.nrows):
      ECU_Tx = Tx_sheet.cell_value(i,0).replace(' ','')
      MsgSendType = Tx_sheet.cell_value(i,4).replace(' ','')
      if MsgSendType == 'Periodic' and (ECU_Tx == 'CCURT1' or ECU_Tx == 'CCURT2'):
        Str = '{"' + ChnName + '::' + Tx_sheet.cell_value(i,1).replace(' ','') + '"},'
        CCUSendFrameArr.append(Str)

    for i in range(Tx_sheet.nrows):
      SignalName = Tx_sheet.cell_value(i,8).replace(' ','')
      ECU_Tx = Tx_sheet.cell_value(i,0).replace(' ','')
      MsgSendType = Tx_sheet.cell_value(i,4).replace(' ','')
      if MsgSendType == 'Periodic' and SignalName[-4:] == '_CRC' and (ECU_Tx == 'CCURT1' or ECU_Tx == 'CCURT2'):
        Str = '{"' + ChnName + '::' + Tx_sheet.cell_value(i,1).replace(' ','') + '"},'
        CounterMsgNameArr.append(Str)

    CycTimeMsgNameArr = getTestID(CounterMsgNameArr,removeArrDupValue(CCUSendFrameArr))

    CounterMsgNum += len(removeArrDupValue(CounterMsgNameArr))
    CycTimeMsgNum += len(CycTimeMsgNameArr)

    for msg in ArrOpera(CounterMsgNameArr):
      file.write('on message ' + msg + '\n{\n  if(Test_Flag)\n  {\n' + '    MsgSendNum[' + str(NumIndex) + '] ++;\n' + '    PacketLossChk_Counter(' + ChnName + ',this.name,this.' + getMsgCounterFrameName(msg) + ',ErrorNum[' + str(NumIndex) + '],CounterArr[' + str(CounterIndex) + '],CurrIndex[' + str(NumIndex) + ']);\n  }\n}\n\n')
      TestMsgIDStrArr.append('"' + getMsgID(msg) + '",')
      TestMsgNameStrArr.append('"' + msg + '",')
      NumIndex += 1
      CounterIndex += 1

    for msg in ArrOpera(CycTimeMsgNameArr):
      file.write('on message ' + msg + '\n{\n  if(Test_Flag)\n  {\n' + '    MsgSendNum[' + str(NumIndex) + '] ++;\n' + '    PacketLossChk_CycTime(' + ChnName + ',this.name,' + getMsgCycTimeNum(msg) +',ErrorNum[' + str(NumIndex) + '],TimeArr[' + str(TimeIndex) + '],CurrIndex[' + str(NumIndex) + ']);\n  }\n}\n\n')
      TestMsgIDStrArr.append('"' + getMsgID(msg) + '",')
      TestMsgNameStrArr.append('"' + msg + '",')
      NumIndex += 1
      TimeIndex += 1

    file.close()
    
    txtfile.write(ChnName + '[' + str(len(removeArrDupValue(CCUSendFrameArr))) + '] :\n\n')

    if index != len(getTxSheet()):
      for name in removeArrDupValue(CCUSendFrameArr):
        txtfile.write(name)
    else:
      for name in DeleteArrLastChar(removeArrDupValue(CCUSendFrameArr)):
        txtfile.write(name)

    txtfile.write('\n\n')
    TotalNum += len(removeArrDupValue(CCUSendFrameArr))
    index += 1

  txtfile.write('########## Total : ' + str(TotalNum)  + ' ##########\n')
  txtfile.close()

  Parameterfilepath = curr_work_dir + '/' + folder_name + '_PacketLossChk/Parameter.cin'
  file = open(Parameterfilepath,'w')
  file.write('/*@!Encoding:1252*/\nvariables\n{\n  // ************************* '+  CMX_name + ' *************************\n\n')
  file.write('  const int TestMsgNum = ' + str(TotalNum) + ';\n')
  file.write('  dword MsgSendNum[TestMsgNum];\n')
  file.write('  dword ErrorNum[TestMsgNum];\n')
  file.write('  byte CurrIndex[TestMsgNum];\n')
  file.write('  int CounterArr[' + str(CounterMsgNum) + '][2];\n')
  file.write('  double TimeArr[' + str(CycTimeMsgNum) + '][2];\n')

  file.write('  char TestMsgID[TestMsgNum][10] = {')
  for _id in DeleteArrLastChar(TestMsgIDStrArr):
    file.write(_id)
  file.write('};\n')

  file.write('  char TestMsgName[TestMsgNum][64] = {')
  for name in DeleteArrLastChar(TestMsgNameStrArr):
    file.write(name)
  file.write('};\n}\n')

  file.close()

def main():
  if Mode == '-x':   #Generate RoutingChart parsing table in the format of .xlsx
    ID_SrcDestChnAnalysis()
    WriteInXlsx()
    print('\n *********** GENERATED FILE SUCCESS !!! ***********')
  elif Mode == '-t': #Generate .cin file for testing
    CreateFolder(folder_name)
    CreateCinFileWrite()
    ID_SrcDestChnAnalysis()
    WriteParameter()
    print('\n *********** GENERATED FILE SUCCESS !!! ***********')
  elif Mode == '-a':
    getAllMsgWriteInTxt()
    print('\n *********** GENERATED FILE SUCCESS !!! ***********')
  elif Mode == '-f':
    global PDF_FileName
    if len(sys.argv) == 4:
      PDF_FileName = sys.argv[3]
      ID_SrcDestChnAnalysis()
      MsgClassify()
      print('\n *********** GENERATED FILE SUCCESS !!! ***********')
    else:
      print('\n ********** DataID.pdf or CMX.xlsx NOT FOUND !!! **********')
  elif Mode == '-s':
    CreateFolder(folder_name + '_PacketLossChk')
    getCCUSendFrame()
    print('\n *********** GENERATED FILE SUCCESS !!! ***********')
  else:
    print("\n ******* Prompt : parameter error,only '-t','-x','-a','-s' or '-f' is supported !!! *******")

if __name__ == '__main__':
  main()

