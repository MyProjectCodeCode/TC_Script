在cmd窗口执行

1、python StartDelayTimeOpera.py -r xxx.cfg

(1)提取xxx.cfg中的IL Configuration-->Start Delay值（之前有改过，没改过的由于文件中没有对应配置字段无法读取到）
(2)提取之后会放在py文件同目录下的DelayTime.ini文件中

2、python StartDelayTimeOpera.py -w

(1)需要把该项目所有的dbc放到Databases文件夹下
(2)py工具同目录下必须有上一步读取到的DelayTime.ini文件
(3)指令执行完毕提示SUCCESS后，需要把py工具路径Databases文件夹下的所有dbc文件复制到项目的Databases文件夹下供Simulation使用