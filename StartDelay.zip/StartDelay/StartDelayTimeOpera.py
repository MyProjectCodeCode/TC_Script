#!/usr/bin/python
# -*- coding:utf-8 -*-

#Author: Liu Qi 
#Version : v1.0

import sys,re,os

def StrContains(SubStr,Str):
  if SubStr in Str:
  	return True
  else:
    return False

def GetMsgData(RowNum):
  CurrArr = []
  CurrRowText = lines[RowNum].replace(' ','').replace('\n','')

  patternChn = r'DatabaseSet::(.*?)::'
  ChnName = re.search(patternChn,CurrRowText).group(1)
  CurrArr.append(ChnName)
  
  patternMsgName = r'MessageSet::(.*?)::'
  MsgName = re.search(patternMsgName,CurrRowText).group(1)
  CurrArr.append(MsgName)
  
  DelayTimeRowText = lines[RowNum+8].replace(' ','').replace('\n','')
  patternDelayTime = r'<IntegerValue>(.*?)</IntegerValue>'
  DelayTimeNumStr = re.search(patternDelayTime,DelayTimeRowText).group(1)
  CurrArr.append(DelayTimeNumStr)
  
  return(CurrArr)

def GetStartRowData():
  global StartRowsNumArr
  StartRowsNumArr = []
  for i in range(TotalRows):
    if lines[i].replace(' ','').replace('\n','') == '<Name>ProxyValue</Name>' and StrContains('GenMsgStartDelayTime',lines[i+1].replace(' ','').replace('\n','')) == True:
      StartRowsNumArr.append(i+1)

def getMsgID(dbcfile,MsgName):

  MsgIDStr = ''
  dbc_text = open(dbcfile,'r').readlines()

  for line in range(len(dbc_text)):
    if dbc_text[line][:3] == 'BO_' and StrContains(MsgName+': ',dbc_text[line]):
      first_space = dbc_text[line].find(' ')
      second_space = dbc_text[line].find(' ',first_space + 1)
        
      MsgIDStr = dbc_text[line][first_space + 1:second_space]

  return(MsgIDStr)

def DelDataInDBC():
  folder_path = curr_work_dir + '\\Databases\\'
  dbc_files = [f for f in os.listdir(folder_path) if f.endswith('.dbc')]
  
  for dbcName in dbc_files:
    dbc_text = open(folder_path + dbcName,'r').readlines()
    for line in range(len(dbc_text)):
      if StrContains('BA_ "GenMsgStartDelayTime" BO_',dbc_text[line]) == True:
        with open(folder_path + dbcName,'w') as file:
          dbc_text[line] = ' \n'
          file.writelines(dbc_text)

def Updata_dbc(dbcfile,MsgName,StartDelayValue):
  
  dbc_text = open(dbcfile,'r').readlines()
  StartLine = 0

  for line in range(len(dbc_text)):
    if StrContains('BA_ "DBName"',dbc_text[line]) == True:
      StartLine = line
      break
  
  with open(dbcfile,'r+') as file:
    dbc_text.insert(StartLine + 1,''.join('BA_ "GenMsgStartDelayTime" BO_ ' + getMsgID(dbcfile,MsgName) + ' ' + StartDelayValue + ';\n'))
    file.seek(0)
    file.writelines(dbc_text)

def WriteDataInDBC():
  ini_filePath = curr_work_dir + '/DelayTime.ini'

  if not os.path.exists(ini_filePath):
    print('\n******* The DelayTime.ini file does not exist, please check !!! *******')
  else:
    DelDataInDBC()
    ini_lines = open(ini_filePath,'r').readlines()

    for i in range(3,len(ini_lines)):
      ChnName = re.search(r'ChnName::(.*?)::MsgName',ini_lines[i]).group(1)
      MsgName = re.search(r'MsgName::(.*?)::DelayTime',ini_lines[i]).group(1)
      delayTime = re.search(r'DelayTime::(.*?)]',ini_lines[i]).group(1)
      Curr_dbc_filePath = curr_work_dir + '\\Databases\\' + ChnName + '.dbc'
      Updata_dbc(Curr_dbc_filePath,MsgName,delayTime)
  
def getMsgDataArr():
  global DataArr
  DataArr = []
  for row in StartRowsNumArr:
    DataSubArr = GetMsgData(row)
    DataArr.append(DataSubArr)

def WriteDataInTxtFile():
  DataFilePath = curr_work_dir + '/' + 'DelayTime.ini'
  DataFile = open(DataFilePath,'w')
  DataFile.write('********** ' + Cfg_name + ' **********\n')
  DataFile.write(str(len(DataArr)) + '\n\n')

  for i in range(len(DataArr)):
  	DataFile.write('[ChnName::' + DataArr[i][0] + '::MsgName::' + DataArr[i][1] + '::DelayTime::' + DataArr[i][2] + ']\n')

  DataFile.close()

def main():
  Mode = sys.argv[1]
  global curr_work_dir
  curr_work_dir = os.path.dirname(__file__)

  if Mode == '-r':
    if len(sys.argv) == 3:
      global CanoeCfg_FilePath
      global Cfg_name
      global Cfg_file
      global lines
      global TotalRows

      CanoeCfg_FilePath = sys.argv[2]
      Cfg_name = re.sub('[\u4e00-\u9fa5]','',os.path.basename(CanoeCfg_FilePath))
      Cfg_file = open(CanoeCfg_FilePath,'r')
      lines = Cfg_file.readlines()
      TotalRows = len(lines)

      GetStartRowData()
      getMsgDataArr()
      WriteDataInTxtFile()
      print('\n********** SUCCESS !!! **********')
    else:
      print('\n********** Parameter or xxx.cfg NOT FOUND !!! **********')
  elif Mode == '-w':
    WriteDataInDBC()
    print('\n********** SUCCESS !!! **********')
  else:
  	print("\n******* Prompt : parameter error,only '-r' or '-w' is supported !!! *******")
  
if __name__ == '__main__':
  main()