import paramiko,datetime,time,sys
from scp import SCPClient

fileName = sys.argv[1]

# 请求服务器获取信息
def sshGetFile(hostname, username, password, file):
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        # 创建SSH链接
        client.connect(hostname=hostname, port=22, username=username, password=password)
        scpclient = SCPClient(client.get_transport(), socket_timeout = 15.0)
        try:
            scpclient.get('/tmp/%s' % file, './PcapFile_Stress_BigData/')
        except FileNotFoundError:
            print("file not found")
    except Exception as e:
        print("[%s] %s target failed, the reason is %s" % (datetime.datetime.now(), hostname, str(e)))
    else:
        print("[%s] %s target success and %s got" % (datetime.datetime.now(), hostname, file))
    finally:
        client.close()


if __name__ == '__main__':
    sshGetFile('10.1.0.79', 'root', '$ww0328_G', fileName)